// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 289);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/credit-level-5_8216c1668d04ce85216a10ba724e480a.png";

/***/ }),
/* 11 */,
/* 12 */,
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var modal = weex.requireModule('modal');
var _network = weex.requireModule('wb-network');
var _router = weex.requireModule('wb-router');
var _location = weex.requireModule('wb-location');
var _modal = weex.requireModule('wb-modal');
var _nativerouter = weex.requireModule('wb-nativerouter');

// const _network = (option, cb) => {
//   setTimeout(() => {
//     cb(option)
//   }, 2000)
// }

// 获取工具栏高度
var toolbar = {
  /**
   * 工具栏高度
   */
  height: function height() {
    var env = weex.config.env;

    var height = _nativerouter.nativeNavigationHeight() / env.deviceWidth * 750;
    return Math.ceil(height);
  }
};

// 加载动画
var loading = {
  /**
   * 打开菊花
   * @param {String} text - 参数
   */
  show: function show(text) {
    _modal.showLoading(text || '加载中...');
  },

  /**
   * 关闭菊花
   */
  hide: function hide() {
    _modal.dismiss();
  }
};

/**
 * 网络请求
 * @param {object} option - 参数
 * @param {string} option.url - 服务器 URL.
 * @param {string} [option.method=get] - 创建请求时使用的方法
 * @param {object} [option.headers={ 'X-Requested-With': 'XMLHttpRequest' }] - 自定义请求头
 * @param {object} [option.params={}] - 请求数据的参数
 * @returns {unknown} - 请求结果,待定
 */
var network = function network(option) {
  return new Promise(function (resolve, reject) {
    var _option = {
      url: null,
      method: 'get',
      // headers: { 'X-Requested-With': 'XMLHttpRequest' },
      params: {}
    };
    var param = Object.assign(_option, option);

    param.method = param.method.toLowerCase();
    console.log('pafram---:' + JSON.stringify(param));
    console.log('url---:' + param.url);
    _network.request(param, function (result) {
      if (result.status === 401) {
        // 原生处理，跳转到登录
        console.log('登录问题，原生处理');
        console.log(result);
        modal.toast({
          message: '401--' + result.error,
          duration: 2
        });
        return;
      }
      // 原生
      // result.status http请求状态码，成功返回200
      // result.error 错误信息
      // result.data 服务器返回的对象

      // 服务器
      // result.data.code:0 成功
      // result.data.code:10001 权限不足
      // result.data.message 成功 >'ok' 异常 > 异常信息
      // result.data.data 服务器返回数据

      if (result.status === 200) {
        if (result.data.code === 0 || result.data.code === '0') {
          resolve(result.data.data);
          console.log('\u8BF7\u6C42\u6210\u529F url:' + param.url);
          console.log(result);
        } else {
          modal.toast({
            message: '\u6570\u636E\u5F02\u5E38--' + JSON.stringify(result.data.message),
            duration: 10
          });
          console.log('数据异常');
          console.error(result);

          reject(result);
        }
      } else {
        modal.toast({
          message: '\u8BF7\u6C42\u51FA\u9519--' + JSON.stringify(result.error) + ' status - ' + result.status,
          duration: 10
        });

        console.log('请求出错');
        console.error(result);

        reject(result);
      }
    });
  });
};

// 页面路由
var router = {
  /**
   * 打开页面
   * @param {object} option - 参数
   * @param {string} option.url - 下一个weex/web的路径
   * @param {string} [option.name] - 页面名称。内置"weex"、"web"，其他路由需要原生先注册
   * @param {string} [option.type=push] - 下一个weex/web的路径
   * @param {boolean} [option.navBarHidden=false] - 是否隐藏导航栏
   * @param {object} [option.params={}] - // 需要传到下一个页面的数据
   */
  open: function open(option) {
    var _option = {
      name: 'weex',
      url: null,
      type: 'push',
      navBarHidden: false,
      params: {}
    };
    var param = Object.assign(_option, option);
    _router.open(param);
  },

  /**
   * 关闭页面
   * @param {string} [level=1] - 关闭页面的级数
   */
  close: function close() {
    var level = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

    _router.close(level);
  },

  /**
   * 刷新weex页面
   */
  refresh: function refresh() {
    _router.refresh();
  },

  /**
   * 获取页面参数
   */
  getParams: function getParams() {
    return _router.getParams();
  }
};

// 地理定位
var location = new Promise(function (resolve, reject) {
  _location.getLocation(function (result) {
    if (result.status === 0) {
      resolve(result.data);
    } else {
      reject(result);
    }
  });
});

exports.default = {
  network: network,
  router: router,
  location: location,
  loading: loading,
  toolbar: toolbar
};

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});


// const host = 'api'
var host = 'http://iquest-test94.aiyuangong.com/api';
/* 接口类别 */
// 任务
var task = host + '/task';

// 好友
var friends = host + '/friends';

// 个人信息
var user = host + '/user';

// 群组
var group = host + '/group';

// 评价
var account = host + '/account';

// 账户
var personal = host + '/personal';

/* eslint-disable no-new */
exports.default = {
  /**
   * 任务
   */

  // 任务-申请任务
  applyTask: task + '/apply',
  // 任务首页 推荐列表
  taskRecommendList: task + '/special/recommendList',
  // 任务首页 最新列表
  taskNewestList: task + '/special/recommendList',
  // 任务首页 附近列表
  taskNearList: task + '/special/recommendList',
  // 任务首页 信用列表
  taskCreditList: task + '/special/recommendList',
  // 任务-过程-列表
  taskProcessList: task + '/processList',
  // 任务 同意参加任务
  taskApproval: task + '/approval',
  // 任务-详情
  taskDetail: task + '/detail',
  // 任务 完成任务列表
  attendList: task + '/attendList',
  // 任务 发布的任务列表
  publishList: task + '/publishList',
  // 任务 最近完成任务列表
  recentlyCompleteTaskList: host + '/personal/recentlyCompleteTaskList',
  // 任务 确认完成任务
  taskComplete: task + '/complete',
  // 任务 打分
  taskEvaluate: task + '/evaluate',
  // 任务 邀请打分
  taskeEaluation: task + '/evaluation',

  /**
   * 好友
   */

  // 好友—关注或者取消关注
  changeFriends: friends + '/changeFriends',
  // 好友-我关注列表(我关注的)
  followListPage: friends + '/followListPage',
  // 好友—获取粉丝列表(关注我的)
  fansListPage: friends + '/fansListPage',

  /**
   * 个人中心
   */

  // 个人信息
  getOne: user + '/getOne',
  // 编辑个人信息
  updateInfo: user + '/updateInfo',
  // 个人视频列表
  UserVideoPage: host + '/video/UserVideoPage',

  /*
  * 账户
  */
  // 冻结列表
  accountFreezeList: account + '/freezeList',
  // 收支记录列表
  accountDetailList: account + '/detailList',
  // 获取钱包余额
  accountBalance: account + '/balance',

  /*
  * 评价
  */
  personalEvaluateList: personal + '/evaluateList',

  /**
   * 群组
   */
  // 群组-创建群
  createGroup: group + '/createGroup',
  // 群组-获取用户加入的群列表
  GroupListPage: group + '/GroupListPage',
  // 群组-获取组成员信息
  getGroupMember: group + '/getGroupMember',
  // 群组-获取群成员列表（分页）
  GroupMemberListPage: group + '/GroupMemberListPage',
  // 群组-获取某一群组信息
  getGroupOne: group + '/getOne',
  // 群组-修改群组信息
  updateGroup: group + '/updateGroup',
  // 群组-邀请加入群
  inviteJoinGroup: group + '/inviteJoinGroup',
  // 群组-用户主动加入群
  joinGroup: group + '/joinGroup'
};

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/* eslint-disable */
/**
 * 获取文本长度 1个中午代表一个字符 一个英文代表半个字符
 * @return: Number
*/
var getStrLength = function getStrLength(str) {
  var len = 0;
  var charCode = -1;
  for (var i = 0; i < str.length; i += 1) {
    charCode = str.charCodeAt(i);
    if (charCode >= 0 && charCode <= 128) {
      // 英文
      len += 0.5;
    } else {
      // 中文
      len += 1;
    }
  }
  // 向上取整数
  return Math.ceil(len);
};

/**
 * 获取weex屏幕真实的设置高度
 * @return: Number
*/
var getScreenHeight = function getScreenHeight() {
  var env = weex.config.env;

  return env.deviceHeight / env.deviceWidth * 750;
};

/**
 * 时间戳转日期
 * @return: String
*/
function ceil(num) {
  return num < 10 ? '0' + num : num;
}
var dataToString = function dataToString(format) {
  var target = (arguments.length <= 1 ? 0 : arguments.length - 1) ? new Date(arguments.length <= 1 ? undefined : arguments[1]) : new Date();
  var rule = {
    y: target.getFullYear(),
    m: ceil(target.getMonth() + 1),
    d: ceil(target.getDate()),
    h: ceil(target.getHours()),
    i: ceil(target.getMinutes()),
    s: ceil(target.getSeconds()),
    w: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][target.getDay()]
  };

  return format.replace('y', rule.y).replace('m', rule.m).replace('d', rule.d).replace('h', rule.h).replace('i', rule.i).replace('s', rule.s).replace('w', rule.w);
};

/**
 * 转换数字 单位 万
 * @return: String
*/
var transformDigital = function transformDigital(num) {
  var dig = parseFloat(num);
  return dig < 10000 ? dig : (dig / 10000).toFixed(2) + 'w';
};

/**
 * 计算剩余时间
 * @param {Number} start - 开始时间戳 毫秒
 * @param {Number} end - 结束时间戳 毫秒
 * @return: String
*/
var dateToHour = function dateToHour(start, end) {
  var differ = end - start;
  // 结束时间小于开始时间
  if (differ <= 0) {
    return '0小时';
  }
  // 计算天数后剩余的小时数
  var ms = differ / (60 * 60 * 1000);
  var hours = Math.ceil(ms);
  return hours < 24 ? hours + '\u5C0F\u65F6' : Math.floor(hours / 24) + '\u5929' + hours % 24 + '\u5C0F\u65F6';
};

/**
 * 获取位置距离
 * @return: String
*/
var transformDistance = function transformDistance(distance) {
  var dis = parseFloat(distance);
  return dis < 1000 ? dis + 'm' : (dis / 1000).toFixed(2) + 'km';
};

/* eslint-disable */
/**
 * 计算两个经纬度之间距离
 * @param {Object} firstDistance - 开始时间戳 毫秒
 * @param {Object} secondDistance - 结束时间戳 毫秒
 * @param {Number} firstDistance.lat 经度
 * @param {Number} firstDistance.lon 纬度
 * @return: String
*/
var getDistance = function getDistance(firstDistance, secondDistance) {
  var radLat1 = parseFloat(firstDistance.lat) * Math.PI / 180.0;
  var radLat2 = parseFloat(secondDistance.lat) * Math.PI / 180.0;
  var a = radLat1 - radLat2;
  var b = parseFloat(firstDistance.lon) * Math.PI / 180.0 - parseFloat(firstDistance.lon) * Math.PI / 180.0;
  var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
  s = s * 6378.137; // EARTH_RADIUS;
  s = Math.round(s * 10000) / 10000;
  // 距离单位为km
  return s < 1 ? (s * 1000).toFixed(0) + 'm' : s.toFixed(2) + 'km';
};

/*
 * 时间格式化
*/
var dateFormat = function dateFormat(d) {
  var pattern = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

  if (!d) {
    return '';
  }
  var date = d;
  if (d instanceof Date) {
    date = d;
  } else {
    date = new Date(d);
  }
  if (!date) {
    return '';
  }
  var o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds(),
    'q+': Math.floor((date.getMonth() + 3) / 3),
    S: date.getMilliseconds()
  };
  if (/(y+)/.test(pattern)) {
    pattern = pattern.replace(RegExp.$1, ('' + date.getFullYear()).substr(4 - RegExp.$1.length));
  }

  for (var k in o) {
    if (new RegExp('(' + k + ')').test(pattern)) {
      pattern = pattern.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }
  }

  return pattern;
};

exports.default = {
  getStrLength: getStrLength,
  getScreenHeight: getScreenHeight,
  transformDistance: transformDistance,
  getDistance: getDistance,
  dataToString: dataToString,
  transformDigital: transformDigital,
  dateToHour: dateToHour,
  dateFormat: dateFormat
};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AiTimeline = exports.AiThumb = exports.AiTag = exports.AiStepper = exports.AiStar = exports.AiSearchbar = exports.AiSearchAddress = exports.AiResult = exports.AiRefresh = exports.AiRate = exports.AiRadio = exports.AiPopover = exports.AiPick = exports.AiPagelist = exports.AiOnloading = exports.AiMask = exports.AiLoading = exports.AiIndexList = exports.AiDialog = exports.AiCheckbox = exports.AiChatHead = exports.AiCellContact = exports.AiCellAddress = exports.AiCell = exports.AiCard = exports.AiButton = undefined;

var _aiButton = __webpack_require__(17);

var _aiButton2 = _interopRequireDefault(_aiButton);

var _aiCard = __webpack_require__(22);

var _aiCard2 = _interopRequireDefault(_aiCard);

var _aiCell = __webpack_require__(47);

var _aiCell2 = _interopRequireDefault(_aiCell);

var _aiCellAddress = __webpack_require__(53);

var _aiCellAddress2 = _interopRequireDefault(_aiCellAddress);

var _aiCellContact = __webpack_require__(58);

var _aiCellContact2 = _interopRequireDefault(_aiCellContact);

var _aiChatHead = __webpack_require__(62);

var _aiChatHead2 = _interopRequireDefault(_aiChatHead);

var _aiCheckbox = __webpack_require__(71);

var _aiCheckbox2 = _interopRequireDefault(_aiCheckbox);

var _aiDialog = __webpack_require__(82);

var _aiDialog2 = _interopRequireDefault(_aiDialog);

var _aiIndexList = __webpack_require__(92);

var _aiIndexList2 = _interopRequireDefault(_aiIndexList);

var _aiLoading = __webpack_require__(97);

var _aiLoading2 = _interopRequireDefault(_aiLoading);

var _aiMask = __webpack_require__(86);

var _aiMask2 = _interopRequireDefault(_aiMask);

var _aiOnloading = __webpack_require__(102);

var _aiOnloading2 = _interopRequireDefault(_aiOnloading);

var _aiPagelist = __webpack_require__(107);

var _aiPagelist2 = _interopRequireDefault(_aiPagelist);

var _aiPick = __webpack_require__(112);

var _aiPick2 = _interopRequireDefault(_aiPick);

var _aiPopover = __webpack_require__(117);

var _aiPopover2 = _interopRequireDefault(_aiPopover);

var _aiRadio = __webpack_require__(122);

var _aiRadio2 = _interopRequireDefault(_aiRadio);

var _aiRate = __webpack_require__(131);

var _aiRate2 = _interopRequireDefault(_aiRate);

var _aiRefresh = __webpack_require__(138);

var _aiRefresh2 = _interopRequireDefault(_aiRefresh);

var _aiResult = __webpack_require__(143);

var _aiResult2 = _interopRequireDefault(_aiResult);

var _aiSearchAddress = __webpack_require__(148);

var _aiSearchAddress2 = _interopRequireDefault(_aiSearchAddress);

var _aiSearchbar = __webpack_require__(152);

var _aiSearchbar2 = _interopRequireDefault(_aiSearchbar);

var _aiStar = __webpack_require__(36);

var _aiStar2 = _interopRequireDefault(_aiStar);

var _aiStepper = __webpack_require__(159);

var _aiStepper2 = _interopRequireDefault(_aiStepper);

var _aiTag = __webpack_require__(164);

var _aiTag2 = _interopRequireDefault(_aiTag);

var _aiThumb = __webpack_require__(26);

var _aiThumb2 = _interopRequireDefault(_aiThumb);

var _aiTimeline = __webpack_require__(169);

var _aiTimeline2 = _interopRequireDefault(_aiTimeline);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 此文件由config/build-entry.js自动生成
exports.AiButton = _aiButton2.default;
exports.AiCard = _aiCard2.default;
exports.AiCell = _aiCell2.default;
exports.AiCellAddress = _aiCellAddress2.default;
exports.AiCellContact = _aiCellContact2.default;
exports.AiChatHead = _aiChatHead2.default;
exports.AiCheckbox = _aiCheckbox2.default;
exports.AiDialog = _aiDialog2.default;
exports.AiIndexList = _aiIndexList2.default;
exports.AiLoading = _aiLoading2.default;
exports.AiMask = _aiMask2.default;
exports.AiOnloading = _aiOnloading2.default;
exports.AiPagelist = _aiPagelist2.default;
exports.AiPick = _aiPick2.default;
exports.AiPopover = _aiPopover2.default;
exports.AiRadio = _aiRadio2.default;
exports.AiRate = _aiRate2.default;
exports.AiRefresh = _aiRefresh2.default;
exports.AiResult = _aiResult2.default;
exports.AiSearchAddress = _aiSearchAddress2.default;
exports.AiSearchbar = _aiSearchbar2.default;
exports.AiStar = _aiStar2.default;
exports.AiStepper = _aiStepper2.default;
exports.AiTag = _aiTag2.default;
exports.AiThumb = _aiThumb2.default;
exports.AiTimeline = _aiTimeline2.default;

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(18);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(19)
)

/* script */
__vue_exports__ = __webpack_require__(20)

/* template */
var __vue_template__ = __webpack_require__(21)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-button/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-323437cf"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = {
  "small": {
    "width": "124",
    "height": "64"
  },
  "medium": {
    "width": "156",
    "height": "64"
  },
  "big": {
    "width": "560",
    "height": "80"
  },
  "large": {
    "width": "690",
    "height": "88"
  },
  "radius": {
    "borderRadius": "6"
  },
  "ai-btn": {
    "justifyContent": "center",
    "alignItems": "center"
  },
  "normal": {
    "backgroundColor": "#ffffff",
    "backgroundImage": "none",
    "borderColor": "#6f4efa",
    "borderWidth": "1"
  },
  "primary": {
    "backgroundColor": "#6f4efa",
    "backgroundImage": "linear-gradient(to right, #cc4def, #6f4efa)",
    "borderWidth": "0"
  },
  "text-primary": {
    "color": "#ffffff"
  },
  "clicked": {
    "backgroundColor": "#f6f7ff",
    "backgroundImage": "none",
    "borderColor": "#dfdfdf",
    "borderWidth": "1"
  },
  "text-clicked": {
    "color": "#6f4efa"
  },
  "disabled": {
    "backgroundColor": "#dfdfdf",
    "backgroundImage": "none"
  },
  "text-disabled": {
    "color": "#ffffff"
  },
  "btn-text": {
    "textAlign": "center",
    "color": "#6f4efa",
    "fontSize": "32"
  }
}

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-button',
  props: {
    text: {
      type: String,
      default: '确认'
    },
    type: {
      type: String,
      default: 'normal'
    },
    size: {
      type: String,
      default: 'medium'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    radius: {
      type: Boolean,
      default: true
    },
    btnStyle: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    textStyle: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {};
  },

  methods: {
    onClicked: function onClicked(e) {
      var type = this.type,
          disabled = this.disabled;

      if (!disabled) {
        this.$emit('click', { e: e, type: type, disabled: disabled });
      }
    }
  }
};

/***/ }),
/* 21 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['ai-btn', _vm.radius && 'radius', _vm.size, _vm.type, _vm.disabled && 'disabled'],
    style: _vm.btnStyle,
    on: {
      "click": _vm.onClicked
    }
  }, [_c('text', {
    class: ['btn-text', _vm.disabled ? 'text-disabled' : ("text-" + _vm.type)],
    style: _vm.textStyle,
    on: {
      "click": _vm.onClicked
    }
  }, [_vm._v(_vm._s(_vm.text))]), _vm._t("default")], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(23);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(24)
)

/* script */
__vue_exports__ = __webpack_require__(25)

/* template */
var __vue_template__ = __webpack_require__(46)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-card/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-01a832a6"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = {
  "container": {
    "paddingBottom": "15"
  },
  "info": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "avator": {
    "width": "56",
    "height": "56",
    "borderRadius": "6"
  },
  "name": {
    "marginLeft": "15",
    "color": "#9b94a1",
    "fontSize": "30",
    "marginRight": "10"
  },
  "ico-grade": {
    "width": "75",
    "height": "30",
    "marginLeft": "10"
  },
  "status": {
    "flexDirection": "row",
    "alignItems": "center",
    "marginTop": "10"
  },
  "icon-img": {
    "width": "24",
    "height": "24",
    "borderRadius": "4"
  },
  "status-txt": {
    "marginLeft": "10",
    "fontSize": "24"
  },
  "flag-push": {
    "color": "#6f4efa"
  },
  "flag-join": {
    "color": "#349fff"
  },
  "flag-complete": {
    "color": "#33c7e6"
  },
  "title": {
    "width": "660",
    "marginTop": "10",
    "fontSize": "32",
    "lineHeight": "40",
    "color": "#3f3453",
    "lines": 2,
    "textOverflow": "ellipsis"
  },
  "wrap": {
    "marginTop": "10",
    "flexDirection": "row",
    "justifyContent": "flex-start"
  },
  "video-img": {
    "width": "150",
    "height": "200"
  },
  "video-txt": {
    "flex": 1,
    "height": "200",
    "fontSize": "28",
    "lineHeight": "38",
    "color": "#9b94a1",
    "marginLeft": "20",
    "textOverflow": "ellipsis",
    "lines": 4
  }
}

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiThumb = __webpack_require__(26);

var _aiThumb2 = _interopRequireDefault(_aiThumb);

var _aiStar = __webpack_require__(36);

var _aiStar2 = _interopRequireDefault(_aiStar);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-card',
  props: {
    headImg: String,
    name: String,
    level: String,
    gradeIcon: String,
    flag: String,
    flagSrc: String,
    text: String,
    title: String,
    img: String,
    vinfo: String,
    likeNum: Number
  },
  // mounted() {
  //     this.lists = this.cards
  //     console.log(this.lists)
  // },
  data: function data() {
    return {
      lists: this.cards
    };
  },

  components: {
    aiThmb: _aiThumb2.default,
    aiStar: _aiStar2.default
  },
  methods: {
    handleClick: function handleClick() {
      this.$emit('clickGoToInfo');
    },
    thumbClick: function thumbClick() {
      this.$emit('thumbClick');
    }
  }
};

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(27);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(28)
)

/* script */
__vue_exports__ = __webpack_require__(29)

/* template */
var __vue_template__ = __webpack_require__(35)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-thumb/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-44bcbd2f"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 28 */
/***/ (function(module, exports) {

module.exports = {
  "task-user": {
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center",
    "paddingTop": "10"
  },
  "user-img": {
    "width": "30",
    "height": "30",
    "marginRight": "10"
  },
  "user-name": {
    "flex": 1,
    "width": "180",
    "lines": 1,
    "textOverflow": "ellipsis",
    "fontSize": "30",
    "color": "#3f3453"
  },
  "user-distance": {
    "fontSize": "30",
    "color": "#beb8c4"
  },
  "ai-thumb-img": {
    "position": "relative"
  },
  "top-icon": {
    "position": "absolute",
    "top": "16",
    "right": "16",
    "height": "34",
    "flexDirection": "row",
    "justifyContent": "flex-end",
    "alignItems": "center"
  },
  "create": {
    "width": "68",
    "height": "34",
    "marginLeft": "4"
  },
  "ongoing": {
    "width": "34",
    "height": "34",
    "marginLeft": "4"
  },
  "thumb-bg": {
    "position": "absolute",
    "bottom": 0,
    "left": 0,
    "right": 0,
    "height": "100",
    "paddingLeft": "16",
    "paddingRight": "16",
    "paddingBottom": "16",
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "flex-end",
    "backgroundImage": "linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.7))"
  },
  "thumb-img-box": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "thumb-img": {
    "width": "26",
    "height": "26",
    "marginRight": "8"
  },
  "thumb-text": {
    "fontSize": "24",
    "color": "#ffffff"
  },
  "thumb-task": {
    "position": "absolute",
    "bottom": 0,
    "left": 0,
    "right": 0,
    "paddingLeft": "16",
    "paddingRight": "16",
    "paddingBottom": "16",
    "height": "210",
    "flexDirection": "column",
    "justifyContent": "flex-end",
    "backgroundImage": "linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.44))"
  },
  "task-title": {
    "fontSize": "28",
    "fontWeight": "bold",
    "color": "#ffffff"
  },
  "task-topic": {
    "fontSize": "24",
    "paddingTop": "8",
    "lines": 1,
    "textOverflow": "ellipsis",
    "color": "#ffffff"
  },
  "task-info": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "marginTop": "8",
    "paddingTop": "8",
    "borderTopColor": "#dfdfdf",
    "borderTopWidth": "1"
  },
  "task-data": {
    "fontSize": "24",
    "color": "#ffffff",
    "paddingRight": "30"
  }
}

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _icoCreat = __webpack_require__(30);

var _icoCreat2 = _interopRequireDefault(_icoCreat);

var _icoJoin = __webpack_require__(31);

var _icoJoin2 = _interopRequireDefault(_icoJoin);

var _underway = __webpack_require__(32);

var _underway2 = _interopRequireDefault(_underway);

var _integral = __webpack_require__(33);

var _integral2 = _interopRequireDefault(_integral);

var _praise = __webpack_require__(34);

var _praise2 = _interopRequireDefault(_praise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-thumb',
  props: {
    type: {
      type: String,
      default: 'video' // video task
    },
    width: {
      type: [Number, String],
      default: 250
    },
    height: {
      type: [Number, String],
      default: 334
    },
    thumbUrl: {
      type: String,
      default: ''
    },
    like: {
      type: [Number, String],
      default: '0'
    },
    integral: {
      type: [Number, String],
      default: '0'
    },
    topic: {
      type: String,
      default: ''
    },
    userImg: {
      type: String,
      default: ''
    },
    userName: {
      type: String,
      default: ''
    },
    userDistance: {
      type: String,
      default: ''
    },
    create: {
      type: Boolean,
      default: false
    },
    join: {
      type: Boolean,
      default: false
    },
    goon: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      CREATE_ICON: _icoCreat2.default,
      JOIN_ICON: _icoJoin2.default,
      ONGOING_ICON: _underway2.default,
      INTEGRAL_ICON: _integral2.default,
      LOVE_ICON: _praise2.default
    };
  },

  computed: {
    style: function style() {
      return {
        width: this.width + 'px',
        height: this.height + 'px'
      };
    }
  },
  watch: {},
  created: function created() {},

  methods: {
    thumbClick: function thumbClick() {
      this.$emit('thumbClick');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/ico-creat_50edd78a95954010b038bfbcc7a4df62.png";

/***/ }),
/* 31 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/ico-join_df1f90b20b02a5be8289e6270f9715a8.png";

/***/ }),
/* 32 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/underway_6cfc3b52439deb44ab5c276ab681018f.png";

/***/ }),
/* 33 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/integral_61de4df3df9f0c553963bbd0b278402c.png";

/***/ }),
/* 34 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/praise_7973dd1f76632dc2372cda2dbfe1e3c1.png";

/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-thumb"],
    style: {
      width: (_vm.width + "px")
    },
    on: {
      "click": _vm.thumbClick
    }
  }, [_c('div', {
    staticClass: ["ai-thumb-img"],
    style: _vm.style
  }, [_c('image', {
    staticClass: ["thumb-img"],
    style: _vm.style,
    attrs: {
      "src": _vm.thumbUrl,
      "resize": "cover"
    }
  }), _c('div', {
    staticClass: ["top-icon"],
    style: {
      width: (_vm.width + "px")
    }
  }, [(_vm.create) ? _c('image', {
    staticClass: ["create"],
    attrs: {
      "src": _vm.CREATE_ICON
    }
  }) : _vm._e(), (_vm.join) ? _c('image', {
    staticClass: ["create"],
    attrs: {
      "src": _vm.JOIN_ICON
    }
  }) : _vm._e(), (_vm.goon) ? _c('image', {
    staticClass: ["ongoing"],
    attrs: {
      "src": _vm.ONGOING_ICON
    }
  }) : _vm._e()]), (_vm.type == 'video') ? _c('div', {
    staticClass: ["thumb-bg"],
    style: {
      width: (_vm.width + "px")
    }
  }, [_c('div', {
    staticClass: ["thumb-img-box"]
  }, [_c('image', {
    staticClass: ["thumb-img"],
    attrs: {
      "resize": "cover",
      "src": _vm.LOVE_ICON
    }
  }), _c('text', {
    staticClass: ["thumb-text"]
  }, [_vm._v(_vm._s(_vm.like))])]), (_vm.integral) ? _c('div', {
    staticClass: ["thumb-img-box"]
  }, [_c('image', {
    staticClass: ["thumb-img"],
    attrs: {
      "resize": "cover",
      "src": _vm.INTEGRAL_ICON
    }
  }), _c('text', {
    staticClass: ["thumb-text"]
  }, [_vm._v(_vm._s(_vm.integral))])]) : _vm._e()]) : _vm._e(), (_vm.type == 'task') ? _c('div', {
    staticClass: ["thumb-task"],
    style: {
      width: (_vm.width + "px")
    }
  }, [_c('text', {
    staticClass: ["task-title"]
  }, [_vm._v("任务")]), _c('text', {
    staticClass: ["task-topic"]
  }, [_vm._v(_vm._s(_vm.topic))]), _c('div', {
    staticClass: ["task-info"]
  }, [_c('image', {
    staticClass: ["thumb-img"],
    attrs: {
      "resize": "cover",
      "src": _vm.LOVE_ICON
    }
  }), _c('text', {
    staticClass: ["task-data"]
  }, [_vm._v(_vm._s(_vm.like))]), _c('image', {
    staticClass: ["thumb-img"],
    attrs: {
      "resize": "cover",
      "src": _vm.INTEGRAL_ICON
    }
  }), _c('text', {
    staticClass: ["task-data"]
  }, [_vm._v(_vm._s(_vm.integral))])])]) : _vm._e()]), (_vm.type == 'task' && (_vm.userImg || _vm.userName || _vm.userDistance)) ? _c('div', {
    staticClass: ["task-user"],
    style: {
      width: (_vm.width + "px")
    }
  }, [_c('image', {
    staticClass: ["user-img"],
    attrs: {
      "src": _vm.userImg
    }
  }), _c('text', {
    staticClass: ["user-name"]
  }, [_vm._v(_vm._s(_vm.userName))]), _c('text', {
    staticClass: ["user-distance"]
  }, [_vm._v(_vm._s(_vm.userDistance))])]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(37);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(38)
)

/* script */
__vue_exports__ = __webpack_require__(39)

/* template */
var __vue_template__ = __webpack_require__(45)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-star/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7277c76f"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 38 */
/***/ (function(module, exports) {

module.exports = {
  "star": {
    "flexDirection": "row"
  },
  "star-icon": {
    "width": "34",
    "height": "32"
  },
  "level-icon": {
    "width": "74",
    "height": "24"
  },
  "level-icon-small": {
    "width": "46",
    "height": "22"
  }
}

/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _creditLevel = __webpack_require__(40);

var _creditLevel2 = _interopRequireDefault(_creditLevel);

var _creditLevel3 = __webpack_require__(41);

var _creditLevel4 = _interopRequireDefault(_creditLevel3);

var _creditLevel5 = __webpack_require__(42);

var _creditLevel6 = _interopRequireDefault(_creditLevel5);

var _creditLevel7 = __webpack_require__(43);

var _creditLevel8 = _interopRequireDefault(_creditLevel7);

var _creditLevel9 = __webpack_require__(10);

var _creditLevel10 = _interopRequireDefault(_creditLevel9);

var _starSmall = __webpack_require__(44);

var _starSmall2 = _interopRequireDefault(_starSmall);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//

var LEVEL_LIST = [{ min: 0, max: 1.9, icon: _creditLevel2.default }, { min: 2, max: 2.9, icon: _creditLevel4.default }, { min: 3, max: 3.9, icon: _creditLevel6.default }, { min: 4, max: 4.9, icon: _creditLevel8.default }, { min: 5, max: 5, icon: _creditLevel10.default }, { min: 5.1, max: 10000, icon: _creditLevel10.default }];

exports.default = {
  name: 'ai-star',
  props: {
    type: {
      type: String,
      default: 'star' // star星星 level等级
    },
    value: {
      type: [String, Number],
      default: 1
    }
  },
  computed: {
    getStar: function getStar() {
      return parseInt(this.value);
    },
    getLevelIcon: function getLevelIcon() {
      var level = parseFloat(this.value);
      // 过滤出对应分值段的数据数组
      var current = LEVEL_LIST.filter(function (val) {
        return level >= val.min && level <= val.max;
      });
      return current.length ? current[0].icon : LEVEL_LIST[0].icon;
    }
  },
  data: function data() {
    return {
      ICON: _starSmall2.default
    };
  },

  watch: {},
  created: function created() {},

  methods: {}
};

/***/ }),
/* 40 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/credit-level-1_7511f8f9949eb66cba2724e117091145.png";

/***/ }),
/* 41 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/credit-level-2_97bfe49233b6ce0cf1893255a0656900.png";

/***/ }),
/* 42 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/credit-level-3_4ffb5f95aa50c8c1238e91b1c46ee7a7.png";

/***/ }),
/* 43 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/credit-level-4_0262574fc635d016f982b753b3481fcf.png";

/***/ }),
/* 44 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/star-small_e9000abbd5b48775b7c218e5e6a5e2ba.png";

/***/ }),
/* 45 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-star"]
  }, [(_vm.type == 'star') ? _c('div', {
    staticClass: ["star"]
  }, _vm._l((_vm.getStar), function(item) {
    return _c('image', {
      key: item,
      staticClass: ["star-icon"],
      attrs: {
        "src": _vm.ICON
      }
    })
  })) : _vm._e(), (_vm.type == 'level') ? _c('image', {
    class: [parseFloat(_vm.value) < 2 ? 'level-icon-small' : 'level-icon'],
    attrs: {
      "src": _vm.getLevelIcon
    }
  }) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 46 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["container"]
  }, [_c('div', {
    staticClass: ["info"],
    on: {
      "click": _vm.handleClick
    }
  }, [_c('image', {
    staticClass: ["avator"],
    attrs: {
      "src": _vm.headImg
    }
  }), _c('text', {
    staticClass: ["name"]
  }, [_vm._v(_vm._s(_vm.name))]), (_vm.level !== '') ? _c('aiStar', {
    attrs: {
      "type": "level",
      "value": _vm.level
    }
  }) : _vm._e()], 1), (_vm.flag === 1) ? _c('div', {
    staticClass: ["status"]
  }, [_c('image', {
    staticClass: ["icon-img"],
    attrs: {
      "src": _vm.flagSrc
    }
  }), _c('text', {
    staticClass: ["status-txt", "flag-push"]
  }, [_vm._v(_vm._s(_vm.text))])]) : _vm._e(), (_vm.flag === 2) ? _c('div', {
    staticClass: ["status"]
  }, [_c('image', {
    staticClass: ["icon-img"],
    attrs: {
      "src": _vm.flagSrc
    }
  }), _c('text', {
    staticClass: ["status-txt", "flag-join"]
  }, [_vm._v(_vm._s(_vm.text))])]) : _vm._e(), (_vm.flag === 3) ? _c('div', {
    staticClass: ["status"]
  }, [_c('image', {
    staticClass: ["icon-img"],
    attrs: {
      "src": _vm.flagSrc
    }
  }), _c('text', {
    staticClass: ["status-txt", "flag-complete"]
  }, [_vm._v(_vm._s(_vm.text))])]) : _vm._e(), (_vm.title) ? _c('text', {
    staticClass: ["title"]
  }, [_vm._v("# " + _vm._s(_vm.title))]) : _vm._e(), (_vm.img) ? _c('div', {
    staticClass: ["wrap"]
  }, [_c('aiThmb', {
    attrs: {
      "width": "150",
      "height": "200",
      "thumbUrl": _vm.img,
      "like": _vm.likeNum
    },
    on: {
      "thumbClick": _vm.thumbClick
    }
  }), (_vm.vinfo) ? _c('text', {
    staticClass: ["video-txt"]
  }, [_vm._v(_vm._s(_vm.vinfo))]) : _vm._e()], 1) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(48);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(49)
)

/* script */
__vue_exports__ = __webpack_require__(50)

/* template */
var __vue_template__ = __webpack_require__(52)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-cell/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-3233b67f"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 49 */
/***/ (function(module, exports) {

module.exports = {
  "ai-cell": {
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center",
    "marginBottom": "1",
    "backgroundColor": "#ffffff"
  },
  "ai-cell-top-border": {
    "borderTopColor": "#dfdfdf",
    "borderTopWidth": "1"
  },
  "ai-cell-bottom-border": {
    "borderBottomColor": "#dfdfdf",
    "borderBottomWidth": "1"
  },
  "ai-cell-label-text": {
    "fontSize": "34",
    "color": "#3f3453",
    "width": "300",
    "marginRight": "10"
  },
  "ai-cell-arrow": {
    "marginLeft": "16"
  },
  "ai-cell-arrow-icon": {
    "width": "18",
    "height": "35"
  },
  "ai-cell-content": {
    "width": "400",
    "flex": 1
  },
  "ai-cell-content-text": {
    "fontSize": "34",
    "textAlign": "right",
    "color": "#665d76",
    "lines": 1,
    "textOverflow": "ellipsis"
  }
}

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _arrowRight = __webpack_require__(51);

var _arrowRight2 = _interopRequireDefault(_arrowRight);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-cell',
  props: {
    label: {
      type: String,
      default: ''
    },
    content: {
      type: String,
      default: ''
    },
    hasArrow: {
      type: Boolean,
      default: false
    },
    arrowIcon: {
      type: String,
      default: _arrowRight2.default
    },
    topBorder: {
      type: Boolean,
      default: false
    },
    bottomBorder: {
      type: Boolean,
      default: true
    },
    paddingLeft: {
      type: [String, Number],
      default: '0'
    },
    paddingTop: {
      type: [String, Number],
      default: '20'
    },
    paddingBottom: {
      type: [String, Number],
      default: '20'
    },
    paddingRight: {
      type: [String, Number],
      default: '30'
    },
    marginLeft: {
      type: [String, Number],
      default: '30'
    },
    style: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  computed: {
    style: function style() {
      return {
        paddingLeft: this.paddingLeft + 'px',
        paddingTop: this.paddingTop + 'px',
        paddingBottom: this.paddingBottom + 'px',
        paddingRight: this.paddingRight + 'px',
        marginLeft: this.marginLeft + 'px'
      };
    }
  },
  data: function data() {
    return {};
  },

  watch: {},
  created: function created() {},

  methods: {
    aiCellClick: function aiCellClick() {
      this.$emit('aiCellClick');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 51 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/arrow-right_3f0be8615cd24e3d59831735259a5a50.png";

/***/ }),
/* 52 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['ai-cell', _vm.topBorder && 'ai-cell-top-border', _vm.bottomBorder && 'ai-cell-bottom-border'],
    style: _vm.style,
    on: {
      "click": _vm.aiCellClick
    }
  }, [_vm._t("label", [(_vm.label) ? _c('div', [_c('text', {
    staticClass: ["ai-cell-label-text"]
  }, [_vm._v(_vm._s(_vm.label))])]) : _vm._e()]), _vm._t("value"), (_vm.content) ? _c('div', {
    staticClass: ["ai-cell-content"]
  }, [_vm._t("content", [_c('text', {
    staticClass: ["ai-cell-content-text"]
  }, [_vm._v(_vm._s(_vm.content))])])], 2) : _vm._e(), (_vm.hasArrow) ? _c('div', {
    staticClass: ["ai-cell-arrow"]
  }, [_c('image', {
    staticClass: ["ai-cell-arrow-icon"],
    attrs: {
      "src": _vm.arrowIcon
    }
  })]) : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(54);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(55)
)

/* script */
__vue_exports__ = __webpack_require__(56)

/* template */
var __vue_template__ = __webpack_require__(57)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-cellAddress/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-f7a58bea"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 55 */
/***/ (function(module, exports) {

module.exports = {
  "ai-cell-address": {
    "alignItems": "flex-start"
  },
  "ai-cell-imgage": {
    "width": "98",
    "paddingTop": "30",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "ai-cell-position-icon": {
    "width": "36",
    "height": "56"
  },
  "ai-cell-address-info": {
    "flex": 1,
    "borderBottomColor": "#dfdfdf",
    "borderBottomWidth": "1",
    "paddingTop": "20",
    "paddingBottom": "20"
  },
  "ai-cell-address-title": {
    "flexDirection": "row",
    "alignItems": "center",
    "justifyContent": "space-between"
  },
  "ai-cell-address-name": {
    "width": "480",
    "lines": 1,
    "textOverflow": "ellipsis",
    "fontSize": "34",
    "color": "#3f3453"
  },
  "ai-cell-address-distance": {
    "fontSize": "24",
    "color": "#beb8c4"
  },
  "ai-cell-address-address": {
    "paddingTop": "4"
  },
  "ai-cell-address-text": {
    "fontSize": "30",
    "color": "#beb8c4",
    "lines": 1,
    "textOverflow": "ellipsis",
    "width": "480"
  },
  "ai-cell-address-other": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "paddingTop": "4"
  },
  "ai-cell-address-other-text": {
    "fontSize": "24",
    "color": "#beb8c4"
  }
}

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-cell-address',
  props: {
    positionIcon: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    distance: {
      type: String,
      default: ''
    },
    address: {
      type: String,
      default: ''
    },
    task: {
      type: [String, Number],
      default: ''
    },
    video: {
      type: [String, Number],
      default: ''
    },
    wrapStyle: {
      type: Object,
      default: function _default() {
        return {
          // paddingLeft: '30px',
          paddingRight: '30px'
        };
      }
    }
  },
  data: function data() {
    return {};
  },

  computed: {
    style: function style() {
      return {
        flexDirection: this.positionIcon ? 'row' : 'column'
      };
    }
  },
  watch: {},
  created: function created() {},

  methods: {
    cellAddressClicked: function cellAddressClicked() {
      this.$emit('cellAddressClicked');
    }
  }
};

/***/ }),
/* 57 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-cell-address"],
    style: _vm.style,
    on: {
      "click": _vm.cellAddressClicked
    }
  }, [(_vm.positionIcon) ? _c('div', {
    staticClass: ["ai-cell-imgage"]
  }, [_c('image', {
    staticClass: ["ai-cell-position-icon"],
    attrs: {
      "src": _vm.positionIcon
    }
  })]) : _vm._e(), _c('div', {
    staticClass: ["ai-cell-address-info"],
    style: _vm.wrapStyle
  }, [_c('div', {
    staticClass: ["ai-cell-address-title"]
  }, [_c('text', {
    staticClass: ["ai-cell-address-name"]
  }, [_vm._v(_vm._s(_vm.title))]), _c('text', {
    staticClass: ["ai-cell-address-distance"]
  }, [_vm._v(_vm._s(_vm.distance))])]), _c('div', {
    staticClass: ["ai-cell-address-address"]
  }, [_c('text', {
    staticClass: ["ai-cell-address-text"]
  }, [_vm._v(_vm._s(_vm.address))])]), (_vm.task || _vm.video) ? _c('div', {
    staticClass: ["ai-cell-address-other"]
  }, [_c('text', {
    staticClass: ["ai-cell-address-other-text"]
  }, [_vm._v(_vm._s(_vm.task) + "任务 ")]), _c('text', {
    staticClass: ["ai-cell-address-other-text"]
  }, [_vm._v(" " + _vm._s(_vm.video) + "视频")])]) : _vm._e()])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(59);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(60)
)

/* script */
__vue_exports__ = __webpack_require__(61)

/* template */
var __vue_template__ = __webpack_require__(70)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-cellContact/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7cd17b37"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 60 */
/***/ (function(module, exports) {

module.exports = {
  "ai-cell-contact": {
    "flexDirection": "row",
    "alignItems": "flex-start"
  },
  "image": {
    "width": "100",
    "paddingTop": "5",
    "borderRadius": "10"
  },
  "contact": {
    "flex": 1,
    "borderBottomColor": "#dfdfdf",
    "borderBottomWidth": "1",
    "marginLeft": "20",
    "flexDirection": "row",
    "alignItems": "center",
    "justifyContent": "space-between"
  },
  "center": {
    "paddingBottom": "20",
    "paddingRight": "15"
  },
  "info": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "image-icon": {
    "width": "100",
    "height": "100",
    "borderRadius": "10"
  },
  "title": {
    "height": "60",
    "lineHeight": "60",
    "maxWidth": "325",
    "color": "#3f3453",
    "fontSize": "34",
    "lines": 1,
    "textOverflow": "ellipsis"
  },
  "num": {
    "color": "#beb8c4"
  },
  "desc": {
    "width": "390",
    "height": "40",
    "lineHeight": "40",
    "paddingTop": "4",
    "fontSize": "28",
    "color": "#beb8c4",
    "lines": 1,
    "textOverflow": "ellipsis"
  }
}

/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiButton = __webpack_require__(17);

var _aiButton2 = _interopRequireDefault(_aiButton);

var _aiStar = __webpack_require__(36);

var _aiStar2 = _interopRequireDefault(_aiStar);

var _aiChatHead = __webpack_require__(62);

var _aiChatHead2 = _interopRequireDefault(_aiChatHead);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-cell-contact',
  components: { AiButton: _aiButton2.default, AiStar: _aiStar2.default, AiChatHead: _aiChatHead2.default },
  props: {
    positionIcon: {
      type: String,
      default: 'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3564877025,796183547&fm=26&gp=0.jpg'
    },
    title: {
      type: String,
      default: ''
    },
    level: {
      type: [String, Number],
      default: ''
    },
    messageNumber: {
      type: [String, Number],
      default: ''
    },
    desc: {
      type: String,
      default: ''
    },
    defaultImgType: {
      type: String,
      default: 'single'
    }
  },
  data: function data() {
    return {};
  },

  watch: {},
  created: function created() {},

  methods: {
    buttonClick: function buttonClick() {
      this.$emit('buttonClick');
    },
    contentClick: function contentClick() {
      this.$emit('contentClick');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(63);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(64)
)

/* script */
__vue_exports__ = __webpack_require__(65)

/* template */
var __vue_template__ = __webpack_require__(69)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-chatHead/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-49fcec16"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 64 */
/***/ (function(module, exports) {

module.exports = {
  "medium": {
    "width": "100",
    "height": "100"
  },
  "small": {
    "width": "56",
    "height": "56"
  }
}

/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//

var _buddha_default3x = __webpack_require__(66);

var _buddha_default3x2 = _interopRequireDefault(_buddha_default3x);

var _group_pictures3x = __webpack_require__(67);

var _group_pictures3x2 = _interopRequireDefault(_group_pictures3x);

var _picture_default3x = __webpack_require__(68);

var _picture_default3x2 = _interopRequireDefault(_picture_default3x);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var defaultImg = {
  single: _buddha_default3x2.default,
  group: _group_pictures3x2.default,
  common: _picture_default3x2.default
};

exports.default = {
  name: 'ai-chat-head',
  props: {
    src: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'medium'
    },
    radius: {
      type: String,
      default: '10'
    },
    resize: {
      type: String,
      default: 'cover'
    },
    defaultImgType: {
      type: String,
      default: 'single' // single,group,common
    },
    style: {
      type: Object,
      default: {}
    }
  },
  methods: {
    style: function style() {
      return _extends({
        'border-radius': this.radius + 'px'
      }, this.style);
    },
    onImageLoad: function onImageLoad(e) {
      if (!e.success) {
        this.src = defaultImg[this.defaultImgType];
      }
    }
  }
};

/***/ }),
/* 66 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/buddha_default@3x_21cdbc31bdf94f25380bb62d331628a7.png";

/***/ }),
/* 67 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/group_pictures@3x_420a8048e151d85e4f767ae9893b3ba3.png";

/***/ }),
/* 68 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/picture_default@3x_91bb8fc306bc797495a9b49bc8921605.png";

/***/ }),
/* 69 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('image', {
    class: ['chat-head', _vm.radius && 'radius', _vm.type],
    style: _vm.style(),
    attrs: {
      "src": _vm.src,
      "resize": _vm.resize
    },
    on: {
      "load": _vm.onImageLoad
    }
  })
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 70 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-cell-contact"]
  }, [_c('div', {
    staticClass: ["image"],
    on: {
      "click": _vm.contentClick
    }
  }, [(_vm.positionIcon) ? _c('ai-chat-head', {
    attrs: {
      "src": _vm.positionIcon,
      "defaultImgType": _vm.defaultImgType
    }
  }) : _vm._e()], 1), _c('div', {
    staticClass: ["contact"]
  }, [_c('div', {
    staticClass: ["center"],
    on: {
      "click": _vm.contentClick
    }
  }, [_c('div', {
    staticClass: ["info"]
  }, [_c('text', {
    staticClass: ["title"]
  }, [_vm._v(_vm._s(_vm.title))]), (_vm.messageNumber) ? _c('text', {
    staticClass: ["num"]
  }, [_vm._v("(" + _vm._s(_vm.messageNumber) + ")")]) : _vm._e(), (_vm.level !== '') ? _c('ai-star', {
    attrs: {
      "type": "level",
      "value": _vm.level
    }
  }) : _vm._e()], 1), _c('text', {
    staticClass: ["desc"]
  }, [_vm._v(_vm._s(_vm.desc))])]), _c('div', {
    staticClass: ["btn"],
    on: {
      "click": _vm.buttonClick
    }
  }, [_vm._t("button")], 2)])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(72);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(73)
)

/* script */
__vue_exports__ = __webpack_require__(74)

/* template */
var __vue_template__ = __webpack_require__(81)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-checkbox/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-e5d51ac0"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 73 */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _item = __webpack_require__(75);

var _item2 = _interopRequireDefault(_item);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-checkbox',
  components: { AiCheckBox: _item2.default },
  props: {
    list: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    name: {
      type: String,
      default: 'title'
    },
    img: {
      type: String,
      default: 'img'
    },
    topBorder: {
      type: Boolean,
      default: false
    },
    bottomBorder: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      checkedList: []
    };
  },

  watch: {
    list: {
      handler: function handler() {
        this.updateList();
      },

      deep: true
    }
  },
  created: function created() {
    // this.updateList()
  },

  methods: {
    updateList: function updateList() {
      var _this = this;

      var list = this.list;

      if (list && list.length > 0) {
        list.forEach(function (item) {
          item.checked && _this.checkedList.push(item);
        });
      }
    },
    aiCellClick: function aiCellClick(e) {
      if (e.checked) {
        this.checkedList.push(e.item);
      } else {
        var index = this.checkedList.indexOf(e.item);
        this.checkedList.splice(index, 1);
      }
      this.$emit('aiCheckListChecked', this.checkedList);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(76)
)

/* script */
__vue_exports__ = __webpack_require__(77)

/* template */
var __vue_template__ = __webpack_require__(80)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-checkbox/item.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-b1df8596"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 76 */
/***/ (function(module, exports) {

module.exports = {
  "radio": {
    "width": "46",
    "height": "46"
  },
  "portrait": {
    "width": "72",
    "height": "72",
    "borderRadius": "8",
    "marginLeft": "28",
    "marginRight": "24"
  },
  "info": {
    "flex": 1,
    "flexDirection": "row",
    "alignItems": "center"
  },
  "name": {
    "width": "340",
    "fontSize": "34",
    "color": "#3f3453",
    "lines": 1,
    "textOverflow": "ellipsis"
  }
}

/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiCell = __webpack_require__(47);

var _aiCell2 = _interopRequireDefault(_aiCell);

var _checkDefault = __webpack_require__(78);

var _checkDefault2 = _interopRequireDefault(_checkDefault);

var _checkActive = __webpack_require__(79);

var _checkActive2 = _interopRequireDefault(_checkActive);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-checkbox-item',
  components: { AiCell: _aiCell2.default },
  props: {
    topBorder: {
      type: Boolean,
      default: false
    },
    bottomBorder: {
      type: Boolean,
      default: true
    },
    item: {
      type: Object,
      require: {}
    },
    title: {
      type: String,
      default: 'title'
    },
    img: {
      type: String,
      default: 'img'
    }
  },
  data: function data() {
    return {
      unCheckedIcon: _checkDefault2.default,
      checkedIcon: _checkActive2.default,
      innerChecked: false
    };
  },

  computed: {
    checkIcon: function checkIcon() {
      var innerChecked = this.innerChecked;

      return innerChecked ? this.checkedIcon : this.unCheckedIcon;
    }
  },
  watch: {
    checked: function checked(newChecked) {
      this.innerChecked = newChecked;
    }
  },
  created: function created() {
    this.innerChecked = this.item.checked;
  },

  methods: {
    aiCellClick: function aiCellClick() {
      var innerChecked = this.innerChecked,
          item = this.item;

      this.innerChecked = !innerChecked;
      this.$emit('aiCellClick', { item: item, checked: this.innerChecked });
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 78 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/check-default_32a2743ba31c60cfd4dfa401bbf6e6c3.png";

/***/ }),
/* 79 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/check-active_95ece4b9991a1d64669c6faa86dfa72a.png";

/***/ }),
/* 80 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ai-cell', {
    attrs: {
      "topBorder": _vm.topBorder,
      "bottomBorder": _vm.bottomBorder
    },
    on: {
      "aiCellClick": _vm.aiCellClick
    }
  }, [_c('div', {
    attrs: {
      "slot": "label"
    },
    slot: "label"
  }, [_c('image', {
    staticClass: ["radio"],
    attrs: {
      "src": _vm.checkIcon
    }
  })]), _c('div', {
    staticClass: ["info"],
    attrs: {
      "slot": "value"
    },
    slot: "value"
  }, [(_vm.item[_vm.img]) ? _c('image', {
    staticClass: ["portrait"],
    attrs: {
      "src": _vm.item[_vm.img]
    }
  }) : _vm._e(), _c('text', {
    staticClass: ["name"]
  }, [_vm._v(_vm._s(_vm.item[_vm.title]))])])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 81 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', _vm._l((_vm.list), function(item, i) {
    return _c('AiCheckBox', {
      key: i,
      attrs: {
        "item": item,
        "title": _vm.name,
        "img": _vm.img,
        "topBorder": _vm.topBorder,
        "bottomBorder": _vm.bottomBorder
      },
      on: {
        "aiCellClick": _vm.aiCellClick
      }
    })
  }))
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(83);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(84)
)

/* script */
__vue_exports__ = __webpack_require__(85)

/* template */
var __vue_template__ = __webpack_require__(91)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-dialog/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-753fea65"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 84 */
/***/ (function(module, exports) {

module.exports = {
  "ai-dialog": {
    "position": "fixed",
    "top": "200",
    "left": "50",
    "right": "50",
    "backgroundColor": "#ffffff",
    "borderRadius": "10"
  },
  "close-ico": {
    "position": "fixed",
    "top": "200",
    "right": "50",
    "backgroundColor": "#ff9900",
    "width": "30",
    "height": "30"
  }
}

/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiMask = __webpack_require__(86);

var _aiMask2 = _interopRequireDefault(_aiMask);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-dialog',
  props: {
    showDialog: {
      type: [Boolean, String],
      default: false
    },
    height: {
      type: [Number, String],
      default: 400
    },
    top: {
      type: [Number, String],
      dafault: 200
    }
  },
  components: {
    aiMask: _aiMask2.default
  },
  data: function data() {
    return {};
  },

  watch: {
    // showDialog(val) {
    //     this.$emit('input', val);
    // }
  },
  methods: {
    _clickMask: function _clickMask() {
      this.$emit('closeDialog');
    },
    onCloseDialog: function onCloseDialog() {
      this.$emit('closeDialog');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(87);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(88)
)

/* script */
__vue_exports__ = __webpack_require__(89)

/* template */
var __vue_template__ = __webpack_require__(90)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-mask/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-286f60ee"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 88 */
/***/ (function(module, exports) {

module.exports = {
  "ai-mask": {
    "position": "fixed",
    "top": 0,
    "left": 0,
    "right": 0,
    "bottom": 0,
    "backgroundColor": "rgba(0,0,0,0.5)"
  }
}

/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-mask',
  props: {
    rgba: {
      type: [String, Number],
      default: 0.5
    }
  },
  data: function data() {
    return {};
  },

  methods: {
    onClick: function onClick() {
      this.$emit('click');
    }
  }
};

/***/ }),
/* 90 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-mask"],
    style: {
      'background-color': 'rgba(0,0,0,' + _vm.rgba + ')'
    },
    on: {
      "click": _vm.onClick
    }
  })
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 91 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (_vm.showDialog) ? _c('div', [_c('ai-mask', {
    on: {
      "click": _vm._clickMask
    }
  }), _c('div', {
    staticClass: ["ai-dialog"],
    style: {
      height: _vm.height + 'px',
      top: _vm.top + 'px'
    }
  }, [_c('scroller', [_vm._t("default")], 2), _c('div', {
    staticClass: ["close-ico"],
    style: {
      top: _vm.top + 'px'
    },
    on: {
      "click": _vm.onCloseDialog
    }
  })])], 1) : _vm._e()
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(93);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(94)
)

/* script */
__vue_exports__ = __webpack_require__(95)

/* template */
var __vue_template__ = __webpack_require__(96)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-indexList/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-001cf069"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 94 */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiCheckbox = __webpack_require__(71);

var _aiCheckbox2 = _interopRequireDefault(_aiCheckbox);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-index-list',
  components: { AiCheckbox: _aiCheckbox2.default },
  props: {
    type: {
      type: Number,
      default: 1 // 1多选 2单选
    },
    list: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    scrollHeight: {
      type: [String, Number],
      default: ''
    }
  },
  computed: {
    setScrollHeight: function setScrollHeight() {
      return {
        height: this.scrollHeight + 'px'
      };
    }
  },
  data: function data() {
    return {};
  },

  watch: {},
  created: function created() {},

  methods: {
    aiCheckListChecked: function aiCheckListChecked(e) {
      // const { checkedList } = e
      this.$emit('currentList', this.type === 1 ? e.checkedList : e);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 96 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    style: _vm.scrollHeight ? _vm.setScrollHeight : {}
  }, [(_vm.type === 1) ? _c('ai-checkbox', {
    attrs: {
      "list": _vm.list,
      "topBorder": false,
      "bottomBorder": true
    },
    on: {
      "aiCheckListChecked": _vm.aiCheckListChecked
    }
  }) : _vm._e(), (_vm.type === 2) ? _c('ai-radio', {
    attrs: {
      "list": _vm.list,
      "topBorder": false,
      "bottomBorder": true
    },
    on: {
      "aiRadioListChecked": _vm.aiCheckListChecked
    }
  }) : _vm._e()], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(98);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(99)
)

/* script */
__vue_exports__ = __webpack_require__(100)

/* template */
var __vue_template__ = __webpack_require__(101)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-loading/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-ba6924d6"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 99 */
/***/ (function(module, exports) {

module.exports = {
  "ai-loading": {
    "position": "fixed",
    "top": "350",
    "width": "750",
    "height": "150",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "load-image": {
    "height": "75",
    "width": "75"
  },
  "load-text": {
    "color": "#ffffff",
    "fontSize": "30"
  }
}

/***/ }),
/* 100 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiMask = __webpack_require__(86);

var _aiMask2 = _interopRequireDefault(_aiMask);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-loading',
  props: {
    show: {
      type: Boolean,
      default: false
    },
    message: {
      type: String,
      default: '加载中。。。'
    },
    txtStyle: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {};
  },

  components: {
    aiMask: _aiMask2.default
  }

}; //
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 101 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (_vm.show) ? _c('div', [_c('ai-mask'), _c('div', {
    staticClass: ["ai-loading"]
  }, [_c('image', {
    staticClass: ["load-image"],
    attrs: {
      "src": "https://vuejs.org/images/logo.png",
      "resize": "contain"
    }
  }), _c('text', {
    staticClass: ["load-text"],
    style: _vm.txtStyle
  }, [_vm._v(_vm._s(_vm.message))])])], 1) : _vm._e()
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(103);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(104)
)

/* script */
__vue_exports__ = __webpack_require__(105)

/* template */
var __vue_template__ = __webpack_require__(106)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-onloading/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-e9c83bd4"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 104 */
/***/ (function(module, exports) {

module.exports = {
  "loading": {
    "height": "150",
    "flexDirection": "row",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "indicator-text": {
    "color": "#beb8c4",
    "fontSize": "22",
    "textAlign": "center"
  },
  "indicator": {
    "height": "40",
    "width": "40",
    "color": "#beb8c4",
    "backgroundColor": "#ffffff"
  }
}

/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-onloading',
  props: {
    loadingText: {
      type: String,
      default: '正在加载中。。。'
    },
    showIcon: {
      type: [Boolean, String],
      default: true
    },
    showIndicator: {
      type: [Boolean],
      default: false
    }
  },
  data: function data() {
    return {};
  },

  methods: {
    onloading: function onloading() {
      this.$emit('onloading');
    }
  }
};

/***/ }),
/* 106 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('loading', {
    staticClass: ["loading"],
    attrs: {
      "display": _vm.showIndicator ? 'show' : 'hide'
    },
    on: {
      "loading": _vm.onloading
    }
  }, [_c('text', {
    staticClass: ["indicator-text"]
  }, [_vm._v(_vm._s(_vm.loadingText))]), (_vm.showIcon) ? _c('loading-indicator', {
    staticClass: ["indicator"]
  }) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 107 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(108);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(109)
)

/* script */
__vue_exports__ = __webpack_require__(110)

/* template */
var __vue_template__ = __webpack_require__(111)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-pagelist/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-054ba3ec"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 109 */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),
/* 110 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiOnloading = __webpack_require__(102);

var _aiOnloading2 = _interopRequireDefault(_aiOnloading);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

// 关注a用户的人（a用户的粉丝）


// const modal = weex.requireModule('modal')
// const LOADMORE_COUNT = 8


exports.default = {
  name: 'ai-pagelist',
  components: _defineProperty({}, _aiOnloading2.default.name, _aiOnloading2.default),
  props: {
    nomore: {
      type: [Boolean],
      default: false
    },
    loading: {
      type: [Boolean],
      default: false
    }
  },
  data: function data() {
    return {
      loadingText: '上拉加载更多'
    };
  },

  watch: {
    nomore: function nomore(val) {
      if (val) {
        this.loadingText = '没有更多了';
        this.loadinging = false;
      }
    }
  },
  methods: {
    loadmore: function loadmore() {
      this.$emit('loadmore');
    }
  }
};

/***/ }),
/* 111 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('list', {
    attrs: {
      "loadmoreoffset": "10"
    }
  }, [_vm._t("default"), _c('ai-onloading', {
    attrs: {
      "loadingText": _vm.loadingText,
      "showIndicator": _vm.loading,
      "showIcon": true
    },
    on: {
      "onloading": _vm.loadmore
    }
  })], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(113);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(114)
)

/* script */
__vue_exports__ = __webpack_require__(115)

/* template */
var __vue_template__ = __webpack_require__(116)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-pick/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-eb40eb04"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 114 */
/***/ (function(module, exports) {

module.exports = {
  "wrap": {
    "width": "300",
    "height": "200",
    "justifyContent": "center",
    "alignItems": "center",
    "backgroundImage": "linear-gradient(to right, #cc4def, #6f4efa)",
    "backgroundColor": "#cccccc",
    "borderRadius": "20"
  },
  "txt": {
    "color": "#ffffff",
    "fontSize": "34"
  },
  "container": {
    "flexDirection": "row"
  },
  "wrapper": {
    "flexDirection": "column",
    "justifyContent": "center"
  },
  "group": {
    "flexDirection": "row",
    "justifyContent": "center",
    "marginBottom": "40",
    "alignItems": "center"
  },
  "label": {
    "fontSize": "24",
    "color": "#888888"
  },
  "title": {
    "fontSize": 28,
    "color": "#41B883"
  },
  "button": {
    "fontSize": "28",
    "width": "280",
    "color": "#41B883",
    "textAlign": "center",
    "paddingTop": "25",
    "paddingBottom": "25",
    "borderWidth": "2",
    "borderStyle": "solid",
    "borderColor": "#a2d9c0",
    "backgroundColor": "rgba(162,217,192,0.2)"
  }
}

/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var picker = weex.requireModule('picker');

exports.default = {
  name: 'ai-pick',
  data: function data() {
    return {
      test: '123',
      timeValue: '',
      dataValue: '',
      pickValue: '',
      items: ['男', '女', '未知']
    };
  },

  methods: {
    pickTime: function pickTime() {
      var _this = this;

      picker.pickTime({
        value: this.timeValue
      }, function (event) {
        if (event.result === 'success') {
          _this.timeValue = event.data;
        }
      });
    },
    pickDate: function pickDate() {
      var _this2 = this;

      picker.pickDate({
        value: this.dataValue
      }, function (event) {
        if (event.result === 'success') {
          console.log(event);
          _this2.dataValue = event.data;
        }
      });
    },
    pickAlone: function pickAlone() {
      var _this3 = this;

      picker.pick({
        items: ['男', '女', '未知'],
        index: 2,
        textColor: '#9cc813',
        selectionColor: '#efefef',
        confirmTitle: 'sure',
        cancelTitle: '取消',
        confirmTitleColor: '#6f4efa',
        title: '性别'
      }, function (e) {
        if (e.result === 'success') {
          console.log(e);
          _this3.pickValue = _this3.items[e.data];
        }
      });
    }
  }

};

/***/ }),
/* 116 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["container"]
  }, [_c('div', {
    staticClass: ["wrapper"]
  }, [_c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["label"]
  }, [_vm._v("Time: ")]), _c('text', {
    staticClass: ["title"]
  }, [_vm._v(_vm._s(_vm.timeValue))])]), _c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["button"],
    on: {
      "click": _vm.pickTime
    }
  }, [_vm._v("Pick Time")])])]), _c('div', {
    staticClass: ["wrapper"]
  }, [_c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["label"]
  }, [_vm._v("Date: ")]), _c('text', {
    staticClass: ["title"]
  }, [_vm._v(_vm._s(_vm.dataValue))])]), _c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["button"],
    on: {
      "click": _vm.pickDate
    }
  }, [_vm._v("Pick Date")])])]), _c('div', {
    staticClass: ["wrapper"]
  }, [_c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["label"]
  }, [_vm._v("pick: ")]), _c('text', {
    staticClass: ["title"]
  }, [_vm._v(_vm._s(_vm.pickValue))])]), _c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["button"],
    on: {
      "click": _vm.pickAlone
    }
  }, [_vm._v("Pick")])])])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(118);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(119)
)

/* script */
__vue_exports__ = __webpack_require__(120)

/* template */
var __vue_template__ = __webpack_require__(121)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-popover/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-1b11fbbe"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 119 */
/***/ (function(module, exports) {

module.exports = {
  "ai-popover": {
    "position": "fixed",
    "zIndex": 10,
    "backgroundColor": "#ffffff",
    "borderWidth": "1",
    "borderColor": "#dfdfdf",
    "boxShadow": "0 1px -9px 2px rgba(0, 0, 0, 0.1)",
    "borderRadius": "10"
  },
  "ai-inner": {
    "width": "280",
    "paddingLeft": "60",
    "paddingRight": "60",
    "borderBottomWidth": "1",
    "borderBottomColor": "#dfdfdf"
  },
  "i-li-noborder": {
    "borderBottomColor": "#ffffff"
  },
  "ai-txt": {
    "height": "90",
    "lineHeight": "90",
    "color": "#665d76",
    "fontSize": "30"
  }
}

/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiMask = __webpack_require__(86);

var _aiMask2 = _interopRequireDefault(_aiMask);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-popover',
  props: {
    lists: {
      type: Array,
      default: []
    },
    position: {
      type: Object,
      default: function _default() {
        return {
          X: 0,
          y: 0
        };
      }
    }
  },
  data: function data() {
    return {
      show: false
    };
  },

  computed: {
    popoverStyle: function popoverStyle() {
      var _position = this.position,
          _position$x = _position.x,
          x = _position$x === undefined ? 0 : _position$x,
          _position$y = _position.y,
          y = _position$y === undefined ? 0 : _position$y;

      var style = {};

      x < 0 ? style.right = -x + 'px' : style.left = x + 'px';
      y < 0 ? style.bottom = -y + 'px' : style.top = y + 'px';
      return style;
    }
  },
  components: {
    aiMask: _aiMask2.default
  },
  methods: {
    listItemClick: function listItemClick(index, key) {
      this.$emit('clickItem', { key: key, index: index });
      this.hideAction();
    },
    showAction: function showAction() {
      this.show = true;
    },
    hideAction: function hideAction() {
      this.show = false;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 121 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (_vm.show) ? _c('div', {
    staticClass: ["container"]
  }, [_c('ai-mask', {
    attrs: {
      "rgba": "0"
    },
    on: {
      "click": _vm.hideAction
    }
  }), _c('div', {
    staticClass: ["ai-popover"],
    style: _vm.popoverStyle
  }, _vm._l((_vm.lists), function(item, i) {
    return _c('div', {
      key: i,
      class: ['ai-inner', i === _vm.lists.length - 1 ? 'i-li-noborder' : ''],
      on: {
        "click": function($event) {
          _vm.listItemClick(i, item.key)
        }
      }
    }, [_c('text', {
      staticClass: ["ai-txt"]
    }, [_vm._v(_vm._s(item.text))])])
  }))], 1) : _vm._e()
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(123);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(124)
)

/* script */
__vue_exports__ = __webpack_require__(125)

/* template */
var __vue_template__ = __webpack_require__(130)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-radio/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-03cf15d8"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 124 */
/***/ (function(module, exports) {

module.exports = {}

/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _item = __webpack_require__(126);

var _item2 = _interopRequireDefault(_item);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-radio',
  components: { AiRadioItem: _item2.default },
  props: {
    list: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    name: {
      type: String,
      default: 'title'
    },
    img: {
      type: String,
      default: 'img'
    },
    topBorder: {
      type: Boolean,
      default: false
    },
    bottomBorder: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      // 初始设置checkedIndex，根据findIndex查找下标，无选中时值为-1
      checkedIndex: this.list.findIndex(function (val) {
        return val.checked;
      })
    };
  },

  computed: {
    updateList: function updateList() {
      var checkedIndex = this.checkedIndex,
          list = this.list;

      var updateList = [];
      list && list.forEach(function (item, i) {
        var updateItem = item;
        updateItem.checked = i === checkedIndex;
        updateList.push(updateItem);
      });
      return updateList;
    }
  },
  watch: {},
  created: function created() {},

  methods: {
    aiCellClick: function aiCellClick(i) {
      // const oldIndex = this.checkedIndex
      this.checkedIndex = i;
      this.$emit('aiRadioListChecked', this.list[i]);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(127)
)

/* script */
__vue_exports__ = __webpack_require__(128)

/* template */
var __vue_template__ = __webpack_require__(129)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-radio/item.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-79291c41"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 127 */
/***/ (function(module, exports) {

module.exports = {
  "radio": {
    "width": "46",
    "height": "46"
  },
  "portrait": {
    "width": "72",
    "height": "72",
    "borderRadius": "8",
    "marginLeft": "28",
    "marginRight": "24"
  },
  "info": {
    "flex": 1,
    "flexDirection": "row",
    "alignItems": "center"
  },
  "name": {
    "width": "340",
    "fontSize": "34",
    "color": "#3f3453",
    "lines": 1,
    "textOverflow": "ellipsis"
  }
}

/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiCell = __webpack_require__(47);

var _aiCell2 = _interopRequireDefault(_aiCell);

var _checkDefault = __webpack_require__(78);

var _checkDefault2 = _interopRequireDefault(_checkDefault);

var _checkActive = __webpack_require__(79);

var _checkActive2 = _interopRequireDefault(_checkActive);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-radio-item',
  components: { AiCell: _aiCell2.default },
  props: {
    topBorder: {
      type: Boolean,
      default: false
    },
    bottomBorder: {
      type: Boolean,
      default: true
    },
    item: {
      type: Object,
      require: {}
    },
    title: {
      type: String,
      default: 'title'
    },
    img: {
      type: String,
      default: 'img'
    }
  },
  data: function data() {
    return {
      unCheckedIcon: _checkDefault2.default,
      checkedIcon: _checkActive2.default
    };
  },

  computed: {
    radioIcon: function radioIcon() {
      var checked = this.item.checked;

      return checked ? this.checkedIcon : this.unCheckedIcon;
    }
  },
  watch: {},
  created: function created() {},

  methods: {
    aiCellClick: function aiCellClick() {
      var value = this.value;

      this.$emit('aiCellClick', { value: value });
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 129 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ai-cell', {
    attrs: {
      "topBorder": _vm.topBorder,
      "bottomBorder": _vm.bottomBorder
    },
    on: {
      "aiCellClick": _vm.aiCellClick
    }
  }, [_c('div', {
    attrs: {
      "slot": "label"
    },
    slot: "label"
  }, [_c('image', {
    staticClass: ["radio"],
    attrs: {
      "src": _vm.radioIcon
    }
  })]), _c('div', {
    staticClass: ["info"],
    attrs: {
      "slot": "value"
    },
    slot: "value"
  }, [(_vm.item[_vm.img]) ? _c('image', {
    staticClass: ["portrait"],
    attrs: {
      "src": _vm.item[_vm.img]
    }
  }) : _vm._e(), _c('text', {
    staticClass: ["name"]
  }, [_vm._v(_vm._s(_vm.item[_vm.title]))])])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 130 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', _vm._l((_vm.updateList), function(item, i) {
    return _c('AiRadioItem', {
      key: i,
      attrs: {
        "item": item,
        "title": _vm.name,
        "img": _vm.img,
        "topBorder": _vm.topBorder,
        "bottomBorder": _vm.bottomBorder
      },
      on: {
        "aiCellClick": function($event) {
          _vm.aiCellClick(i, $event)
        }
      }
    })
  }))
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(132);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(133)
)

/* script */
__vue_exports__ = __webpack_require__(134)

/* template */
var __vue_template__ = __webpack_require__(137)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-rate/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-411a9706"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 133 */
/***/ (function(module, exports) {

module.exports = {
  "ai-rate": {
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "ai-rate-text": {
    "fontSize": "34",
    "textAlign": "center"
  },
  "ai-rate-star": {
    "display": "flex",
    "justifyContent": "space-between",
    "alignItems": "center",
    "flexDirection": "row",
    "paddingTop": "50",
    "paddingBottom": "50",
    "paddingLeft": "100",
    "paddingRight": "100"
  },
  "star-icon": {
    "width": "68",
    "height": "66"
  },
  "best": {
    "color": "#db57bf"
  },
  "general": {
    "color": "#3f3453"
  },
  "suggestion": {
    "width": "690",
    "height": "200",
    "paddingTop": "20",
    "paddingBottom": "20",
    "paddingLeft": "20",
    "paddingRight": "20",
    "borderBottomColor": "#dfdfdf",
    "borderBottomWidth": "1",
    "borderTopColor": "#dfdfdf",
    "borderTopWidth": "1",
    "borderLeftColor": "#dfdfdf",
    "borderLeftWidth": "1",
    "borderRightColor": "#dfdfdf",
    "borderRightWidth": "1"
  }
}

/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _starDefault = __webpack_require__(135);

var _starDefault2 = _interopRequireDefault(_starDefault);

var _starActive = __webpack_require__(136);

var _starActive2 = _interopRequireDefault(_starActive);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-rate',
  props: {
    value: {
      type: [String, Number],
      default: 0
    },
    text: {
      type: [String, Number],
      default: '请对任务结果做出评价'
    }
  },
  data: function data() {
    return {
      DEFAULT_ICON: _starDefault2.default,
      CURRENT_ICON: _starActive2.default,
      rate: 0, // 评分
      text: '', // 文本
      suggestion: '', // 意见建议
      list: [{ score: 1, text: '差评' }, { score: 2, text: '不满意' }, { score: 3, text: '勉强合格' }, { score: 4, text: '还可以' }, { score: 5, text: '很棒！' }]
    };
  },

  watch: {
    value: function value(val) {
      this.rate = val;
      if (val > 0) this.text = this.list[val - 1].text;
    }
  },
  created: function created() {
    this.rate = this.value;
    this.text = this.value > 0 ? this.list[this.value - 1].text : this.text;
  },

  methods: {
    current: function current(index) {
      this.rate = index + 1;
      this.text = this.list[index].text;
      this.$emit('input', index + 1);
    },
    getSuggestion: function getSuggestion() {
      return this.suggestion;
    }
  }
};

/***/ }),
/* 135 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/star-default_9fc019fca0a9ab6e719fb6fecbd8a0ca.png";

/***/ }),
/* 136 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/star-active_06af490af74a76be49e8b3c158660524.png";

/***/ }),
/* 137 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-rate"]
  }, [_c('text', {
    class: ['ai-rate-text', _vm.rate < 5 ? 'general' : 'best']
  }, [_vm._v(_vm._s(_vm.text))]), _c('div', {
    staticClass: ["ai-rate-star"]
  }, _vm._l((_vm.list), function(item, index) {
    return _c('image', {
      key: index,
      staticClass: ["star-icon"],
      attrs: {
        "src": _vm.rate > index ? _vm.CURRENT_ICON : _vm.DEFAULT_ICON
      },
      on: {
        "click": function($event) {
          _vm.current(index)
        }
      }
    })
  })), (_vm.rate > 0 && _vm.rate < 5) ? _c('textarea', {
    staticClass: ["suggestion"],
    attrs: {
      "placeholder": "请描述不满意的理由，以便改善...",
      "value": (_vm.suggestion)
    },
    on: {
      "input": function($event) {
        _vm.suggestion = $event.target.attr.value
      }
    }
  }) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(139);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(140)
)

/* script */
__vue_exports__ = __webpack_require__(141)

/* template */
var __vue_template__ = __webpack_require__(142)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-refresh/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-58623718"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 140 */
/***/ (function(module, exports) {

module.exports = {
  "refresh": {
    "width": 750,
    "height": "100",
    "flexDirection": "row",
    "justifyContent": "center",
    "alignItems": "center",
    "paddingBottom": "10"
  },
  "indicator-text": {
    "color": "#beb8c4",
    "fontSize": "22",
    "textAlign": "center"
  },
  "indicator": {
    "height": "40",
    "width": "40",
    "color": "#beb8c4",
    "backgroundColor": "#ffffff"
  }
}

/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-refresh',
  props: {
    loadingText: {
      type: String,
      default: '释放立即刷新...'
    },
    showIcon: {
      type: [String, Boolean],
      default: true
    }
  },
  data: function data() {
    return {
      refreshing: false
    };
  },

  methods: {
    onrefresh: function onrefresh() {
      var _this = this;

      this.refreshing = true;
      setTimeout(function () {
        _this.$emit('refreshing');
        _this.refreshing = false;
      }, 1000);
    },
    onpullingdown: function onpullingdown() {}
  }
};

/***/ }),
/* 142 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('refresh', {
    staticClass: ["refresh"],
    attrs: {
      "display": _vm.refreshing ? 'show' : 'hide'
    },
    on: {
      "refresh": _vm.onrefresh,
      "pullingdown": _vm.onpullingdown
    }
  }, [_c('text', {
    staticClass: ["indicator-text"]
  }, [_vm._v(_vm._s(_vm.loadingText))]), (_vm.showIcon) ? _c('loading-indicator', {
    staticClass: ["indicator"]
  }) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(144);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(145)
)

/* script */
__vue_exports__ = __webpack_require__(146)

/* template */
var __vue_template__ = __webpack_require__(147)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-result/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-2087eefa"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 145 */
/***/ (function(module, exports) {

module.exports = {
  "wrap": {
    "position": "absolute",
    "top": 0,
    "left": 0,
    "right": 0,
    "bottom": 0
  },
  "ai-result": {
    "width": "750",
    "flex": 1,
    "alignItems": "center",
    "backgroundColor": "#ffffff"
  },
  "result-image": {
    "width": "320",
    "height": "320"
  },
  "result-content": {
    "marginTop": "36",
    "marginBottom": "36",
    "alignItems": "center"
  },
  "content-text": {
    "fontSize": "30",
    "color": "#beb8c4",
    "height": "42",
    "lineHeight": "42",
    "textAlign": "center"
  }
}

/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiButton = __webpack_require__(17);

var _aiButton2 = _interopRequireDefault(_aiButton);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-result',
  components: { AiButton: _aiButton2.default },
  props: {
    show: {
      type: Boolean,
      default: true
    },
    paddingTop: {
      type: [Number, String],
      default: 232
    },
    customSet: {
      type: Object,
      default: function _default() {
        return {
          button: '刷新试试',
          content: '亲，服务器被外星人搬走了~',
          pic: 'https://cn.vuejs.org/images/logo.png'
        };
      }
    }
  },
  computed: {
    setPaddingTop: function setPaddingTop() {
      return this.paddingTop + 'px';
    }
  },
  data: function data() {
    return {};
  },

  watch: {},
  created: function created() {},

  methods: {
    onClick: function onClick() {
      this.$emit('aiResultButtonClicked');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 147 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (_vm.show) ? _c('div', {
    staticClass: ["wrap"]
  }, [_c('div', {
    staticClass: ["ai-result"],
    style: {
      paddingTop: _vm.setPaddingTop
    }
  }, [_c('image', {
    staticClass: ["result-image"],
    attrs: {
      "ariaHidden": true,
      "src": _vm.customSet.pic
    }
  }), (_vm.customSet.content) ? _c('div', {
    staticClass: ["result-content"]
  }, [_c('text', {
    staticClass: ["content-text"]
  }, [_vm._v(_vm._s(_vm.customSet.content))])]) : _vm._e(), _c('ai-button', {
    attrs: {
      "text": _vm.customSet.button
    },
    on: {
      "click": _vm.onClick
    }
  })], 1)]) : _vm._e()
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(149);

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_index).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(150)
)

/* script */
__vue_exports__ = __webpack_require__(151)

/* template */
var __vue_template__ = __webpack_require__(158)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-searchAddress/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-0ddd49f6"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 150 */
/***/ (function(module, exports) {

module.exports = {
  "address-city": {
    "fontSize": "28",
    "color": "#beb8c4",
    "paddingLeft": "30",
    "paddingRight": "30",
    "paddingTop": "22",
    "paddingBottom": "11"
  },
  "search-title": {
    "backgroundColor": "#ffffff",
    "boxShadow": "0 1px 9px 2px rgba(0, 0, 0, 0.11)"
  },
  "ai-search-address": {
    "backgroundColor": "#ffffff"
  }
}

/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _aiSearchbar = __webpack_require__(152);

var _aiSearchbar2 = _interopRequireDefault(_aiSearchbar);

var _aiCellAddress = __webpack_require__(53);

var _aiCellAddress2 = _interopRequireDefault(_aiCellAddress);

var _positionIcon = __webpack_require__(157);

var _positionIcon2 = _interopRequireDefault(_positionIcon);

var _utils = __webpack_require__(15);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// const modal = weex.requireModule('modal')

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-search-address',
  components: { AiCellAddress: _aiCellAddress2.default, AiSearchBar: _aiSearchbar2.default },
  props: {
    list: {
      type: Array,
      default: []
    }
  },
  computed: {
    getPlace: function getPlace() {
      if (!this.list.length) return '';
      var place = this.list[0];
      return place.city + place.area;
    }
  },
  data: function data() {
    return {
      ADDRESS: _positionIcon2.default
    };
  },

  watch: {},
  created: function created() {},

  methods: {
    getDistance: function getDistance(dis) {
      return _utils2.default.transformDistance(dis);
    },
    cellAddressClicked: function cellAddressClicked(item) {
      this.$emit('current', item);
    },
    onBlur: function onBlur(e) {
      this.$emit('search', e.value);
    }
  }
};

/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CLOSE_ICON = exports.INPUT_ICON = undefined;

var _index = __webpack_require__(153);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;
var INPUT_ICON = exports.INPUT_ICON = 'https://gw.alicdn.com/tfs/TB1FZB.pwMPMeJjy1XdXXasrXXa-30-30.png';
var CLOSE_ICON = exports.CLOSE_ICON = 'https://gw.alicdn.com/tfs/TB1sZB.pwMPMeJjy1XdXXasrXXa-24-24.png';

/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(154)
)

/* script */
__vue_exports__ = __webpack_require__(155)

/* template */
var __vue_template__ = __webpack_require__(156)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-searchbar/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-8516c8f8"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 154 */
/***/ (function(module, exports) {

module.exports = {
  "container": {
    "flexDirection": "row",
    "width": "750",
    "height": "90",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "ai-search-ipt": {
    "position": "absolute",
    "top": "14",
    "width": "570",
    "height": "64",
    "lineHeight": "64",
    "borderRadius": "8",
    "paddingLeft": "72",
    "paddingRight": "60",
    "fontSize": "32",
    "backgroundColor": "#f6f7ff"
  },
  "ai-icon-search": {
    "position": "absolute",
    "width": "30",
    "height": "30",
    "left": "54",
    "top": "32"
  },
  "ai-icon-close": {
    "position": "absolute",
    "width": "30",
    "height": "30",
    "right": "170",
    "top": "32"
  },
  "ai-search-btn": {
    "position": "absolute",
    "right": "30",
    "top": "14",
    "width": "94",
    "height": "64",
    "lineHeight": "64",
    "fontSize": "30",
    "textAlign": "center",
    "backgroundColor": "#ffffff",
    "color": "#9b94a1"
  }
}

/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(152);

exports.default = {
  name: 'ai-searchbar',
  props: {
    allShowCancelTxt: {
      type: [Boolean, String],
      default: false
    },
    inputType: {
      type: String,
      default: 'text'
    },
    returnKeyType: {
      type: String,
      default: 'default'
    },
    autofocus: {
      type: Boolean,
      default: false
    },
    defaultValue: {
      type: String,
      defaule: ''
    },
    placeholder: {
      type: String,
      default: 'search'
    },
    cancelTxt: {
      type: String,
      default: '取消'
    }
  },
  computed: {
    needShowCancel: function needShowCancel() {
      return this.allShowCancelTxt || this.showCancel;
    }
  },
  data: function data() {
    return {
      inputIcon: _index.INPUT_ICON,
      closeIcon: _index.CLOSE_ICON,
      showCancel: false,
      showClose: false,
      value: ''
    };
  },
  created: function created() {
    this.defaultValue && (this.value = this.defaultValue);
  },

  methods: {
    onInput: function onInput(event) {
      this.value = event.value;
      this.showCancel = true;
      this.showClearClose();
      this.$emit('searchOnInput', { value: this.value });
    },
    onBlur: function onBlur() {
      var self = this;
      setTimeout(function () {
        self.showCancel = false;
        self.showClearClose();
        self.$emit('searchOnBlur', { value: self.value });
      }, 10);
    },
    autoBlur: function autoBlur() {
      this.$refs.searchbar.blur();
    },
    onFoucus: function onFoucus() {
      this.showCancel = true;
      this.showClearClose();
      this.$emit('searchOnFocus', { value: this.value });
    },
    clickClose: function clickClose() {
      this.value = '';
      this.showClose && (this.showClose = false);
      this.$emit('clickCloseIcon', { value: this.value });
    },
    clickCancel: function clickCancel() {
      this.autoBlur();
      this.showCancel && (this.showCancel = false);
      this.showClose && (this.showClose = false);
      this.$emit('clickCancelTxt', { value: this.value });
    },
    showClearClose: function showClearClose() {
      this.showClose = this.value.length > 0 && this.showCancel;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 156 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["container"]
  }, [_c('input', {
    ref: "searchbar",
    staticClass: ["ai-search-ipt"],
    style: {
      width: _vm.needShowCancel ? '570px' : '690px'
    },
    attrs: {
      "type": _vm.inputType,
      "returnKeyType": _vm.returnKeyType,
      "autofocus": _vm.autofocus,
      "value": _vm.value,
      "placeholder": _vm.placeholder
    },
    on: {
      "input": _vm.onInput,
      "focus": _vm.onFoucus,
      "blur": _vm.onBlur
    }
  }), _c('image', {
    staticClass: ["ai-icon-search"],
    attrs: {
      "src": _vm.inputIcon
    }
  }), (_vm.showClose) ? _c('image', {
    staticClass: ["ai-icon-close"],
    attrs: {
      "src": _vm.closeIcon
    },
    on: {
      "click": _vm.clickClose
    }
  }) : _vm._e(), (_vm.needShowCancel) ? _c('text', {
    staticClass: ["ai-search-btn"],
    on: {
      "click": _vm.clickCancel
    }
  }, [_vm._v(_vm._s(_vm.cancelTxt) + "\n    ")]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 157 */
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/position-icon_f6759c9b3c7d667553ec6fa938a0f0cc.png";

/***/ }),
/* 158 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-search-address"]
  }, [_c('div', {
    staticClass: ["search-title"]
  }, [_c('ai-search-bar', {
    attrs: {
      "placeholder": "请输入想要查找的位置",
      "inputType": "text"
    },
    on: {
      "searchOnBlur": _vm.onBlur
    }
  })], 1), _c('text', {
    staticClass: ["address-city"]
  }, [_vm._v(_vm._s(_vm.getPlace))]), _c('scroller', {
    staticStyle: {
      paddingBottom: "50px"
    }
  }, _vm._l((_vm.list), function(item) {
    return _c('ai-cell-address', {
      attrs: {
        "wrapStyle": {
          paddingLeft: '0px',
          paddingRight: '30px'
        },
        "positionIcon": _vm.ADDRESS,
        "title": (item.iscurrentlocation ? '(当前位置)' : '') + item.name,
        "distance": _vm.getDistance(item.distance),
        "address": item.address
      },
      on: {
        "cellAddressClicked": function($event) {
          _vm.cellAddressClicked(item)
        }
      }
    })
  }))])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(160);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(161)
)

/* script */
__vue_exports__ = __webpack_require__(162)

/* template */
var __vue_template__ = __webpack_require__(163)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-stepper/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-3972062c"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 161 */
/***/ (function(module, exports) {

module.exports = {
  "ai-step": {
    "flexDirection": "row"
  },
  "ai-miuns": {
    "width": "50",
    "height": "50",
    "backgroundColor": "#6f4efa",
    "borderWidth": "1",
    "borderColor": "#6f4efa",
    "borderRadius": "50",
    "justifyContent": "center",
    "alignItems": "center",
    "alignContent": "center"
  },
  "ai-plus": {
    "width": "50",
    "height": "50",
    "backgroundColor": "#6f4efa",
    "borderWidth": "1",
    "borderColor": "#6f4efa",
    "borderRadius": "50",
    "justifyContent": "center",
    "alignItems": "center",
    "alignContent": "center"
  },
  "limit-line": {
    "backgroundColor": "#ffffff",
    "borderColor": "#dfdfdf"
  },
  "icon-step": {
    "fontSize": "36",
    "color": "#ffffff"
  },
  "limie-step": {
    "color": "#dfdfdf"
  },
  "ai-ipt": {
    "width": "80",
    "lineHeight": "50",
    "fontSize": "34",
    "color": "#665d76",
    "textAlign": "center"
  }
}

/***/ }),
/* 162 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-stepper',
  props: {
    min: {
      type: [String, Number],
      default: 1
    },
    max: {
      type: [String, Number],
      default: 6
    },
    step: {
      type: [String, Number],
      default: 1
    },
    defaultValue: {
      type: [String, Number],
      default: 0
    }
  },
  computed: {
    valData: function valData() {
      return this.val.toString();
    }
  },
  data: function data() {
    return {
      val: 123,
      isLess: false,
      isMore: false
    };
  },

  watch: {
    defaultValue: function defaultValue(num) {
      this.val = num;
    }
  },
  created: function created() {
    this.val = parseInt(this.defaultValue, 10);
  },

  methods: {
    clickMiuns: function clickMiuns() {
      var isMinOver = this.val <= this.min;
      var nowVal = this.val - parseInt(this.step, 10);
      if (isMinOver) {
        this.$emit('valueIsMinOver', { value: this.val });
      } else {
        this.val = nowVal;
        this.clearDisableStyle();
      }
      if (nowVal <= this.min) {
        this.val = parseInt(this.min, 10);
        this.isLess = true;
      }
      this.$emit('valueChange', { value: this.val });
    },
    clickPlus: function clickPlus() {
      var isMaxOver = this.val >= this.max;
      var nowVal = this.val + parseInt(this.step, 10);
      if (isMaxOver) {
        this.$emit('valueIsMaxOver', { value: this.val });
      } else {
        this.val = nowVal;
        this.clearDisableStyle();
      }
      if (nowVal >= this.max) {
        this.val = parseInt(this.max, 10);
        this.isMore = true;
      }
      this.$emit('valueChange', { value: this.val });
    },
    onInput: function onInput(e) {
      this.correctInputValue(e.value);
    },
    onBlur: function onBlur(e) {
      this.correctInputValue(e.value);
    },
    correctInputValue: function correctInputValue(v) {
      if (/^[1-9]\d{0,}$/.test(v) && parseInt(v, 10) >= this.min && parseInt(v, 10) <= this.max) {
        this.val = parseInt(v, 10);
      }
      this.$emit('valueChange', { value: this.val });
    },
    clearDisableStyle: function clearDisableStyle() {
      this.isLess = false;
      this.isMore = false;
    }
  }
};

/***/ }),
/* 163 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["ai-step"]
  }, [_c('div', {
    class: ['ai-miuns', _vm.isLess ? 'limit-line' : ''],
    on: {
      "click": _vm.clickMiuns
    }
  }, [_c('text', {
    class: ['icon-step', _vm.isLess ? 'limie-step' : '']
  }, [_vm._v("-")])]), _c('input', {
    staticClass: ["ai-ipt"],
    attrs: {
      "type": "tel",
      "value": _vm.valData
    },
    on: {
      "input": _vm.onInput,
      "blur": _vm.onBlur
    }
  }), _c('div', {
    class: ['ai-plus', _vm.isMore ? 'limit-line' : ''],
    on: {
      "click": _vm.clickPlus
    }
  }, [_c('text', {
    class: ['icon-step', _vm.isMore ? 'limie-step' : '']
  }, [_vm._v("+")])])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 164 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(165);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 165 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(166)
)

/* script */
__vue_exports__ = __webpack_require__(167)

/* template */
var __vue_template__ = __webpack_require__(168)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-tag/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-1b63851a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 166 */
/***/ (function(module, exports) {

module.exports = {
  "txt": {
    "height": "60",
    "lineHeight": "60",
    "backgroundColor": "#f6f7ff",
    "color": "#665d76",
    "fontSize": "30",
    "paddingLeft": "24",
    "paddingRight": "24",
    "marginRight": "15",
    "marginBottom": "15",
    "borderRadius": "8",
    "maxWidth": "690",
    "lines": 1,
    "textAlign": "center",
    "textOverflow": "ellipsis"
  }
}

/***/ }),
/* 167 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//

exports.default = {
  name: 'ai-tag',
  props: {
    txt: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {};
  },

  methods: {
    handleClick: function handleClick() {
      this.$emit('click');
    }
  }
};

/***/ }),
/* 168 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["container"]
  }, [_c('text', {
    staticClass: ["txt"],
    on: {
      "click": _vm.handleClick
    }
  }, [_vm._v(_vm._s(_vm.txt))])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 169 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__(170);

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _index2.default;

/***/ }),
/* 170 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(171)
)

/* script */
__vue_exports__ = __webpack_require__(172)

/* template */
var __vue_template__ = __webpack_require__(173)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-timeline/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-0305b4c4"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 171 */
/***/ (function(module, exports) {

module.exports = {
  "container": {
    "paddingRight": "40",
    "backgroundColor": "#f6f7ff"
  },
  "timeline": {
    "paddingTop": "50",
    "paddingBottom": "60"
  },
  "line": {
    "position": "absolute",
    "top": 0,
    "bottom": 0,
    "left": "30",
    "width": "1",
    "backgroundColor": "#dfdfdf"
  },
  "time": {
    "width": "180",
    "height": "40",
    "lineHeight": "40",
    "backgroundColor": "#ebecf5",
    "color": "#3f3453",
    "textAlign": "center",
    "fontSize": "24",
    "borderRadius": "40",
    "paddingLeft": "10",
    "paddingRight": "10",
    "marginLeft": "-15"
  },
  "content": {
    "marginTop": "30",
    "marginLeft": "50"
  }
}

/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-timeline',
  props: {
    time: {
      type: String,
      default: ''
    },
    content: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {};
  }
};

/***/ }),
/* 173 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["container"]
  }, [_c('div', {
    staticClass: ["timeline"]
  }, [_c('div', {
    staticClass: ["line"]
  }), _c('text', {
    staticClass: ["time"]
  }, [_vm._v(_vm._s(_vm.time))]), _c('div', {
    staticClass: ["content"]
  }, [_vm._t("default")], 2)])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 174 */,
/* 175 */,
/* 176 */,
/* 177 */,
/* 178 */,
/* 179 */,
/* 180 */,
/* 181 */,
/* 182 */,
/* 183 */,
/* 184 */,
/* 185 */,
/* 186 */,
/* 187 */,
/* 188 */,
/* 189 */,
/* 190 */,
/* 191 */,
/* 192 */,
/* 193 */,
/* 194 */,
/* 195 */,
/* 196 */,
/* 197 */,
/* 198 */,
/* 199 */,
/* 200 */,
/* 201 */,
/* 202 */,
/* 203 */,
/* 204 */,
/* 205 */,
/* 206 */,
/* 207 */,
/* 208 */,
/* 209 */,
/* 210 */,
/* 211 */,
/* 212 */,
/* 213 */,
/* 214 */,
/* 215 */,
/* 216 */,
/* 217 */,
/* 218 */,
/* 219 */,
/* 220 */,
/* 221 */,
/* 222 */,
/* 223 */,
/* 224 */,
/* 225 */,
/* 226 */,
/* 227 */,
/* 228 */,
/* 229 */,
/* 230 */,
/* 231 */,
/* 232 */,
/* 233 */,
/* 234 */,
/* 235 */,
/* 236 */,
/* 237 */,
/* 238 */,
/* 239 */,
/* 240 */,
/* 241 */,
/* 242 */,
/* 243 */,
/* 244 */,
/* 245 */,
/* 246 */,
/* 247 */,
/* 248 */,
/* 249 */,
/* 250 */,
/* 251 */,
/* 252 */,
/* 253 */,
/* 254 */,
/* 255 */,
/* 256 */,
/* 257 */,
/* 258 */,
/* 259 */,
/* 260 */,
/* 261 */,
/* 262 */,
/* 263 */,
/* 264 */,
/* 265 */,
/* 266 */,
/* 267 */,
/* 268 */,
/* 269 */,
/* 270 */,
/* 271 */,
/* 272 */,
/* 273 */,
/* 274 */,
/* 275 */,
/* 276 */,
/* 277 */,
/* 278 */,
/* 279 */,
/* 280 */,
/* 281 */,
/* 282 */,
/* 283 */,
/* 284 */,
/* 285 */,
/* 286 */,
/* 287 */,
/* 288 */,
/* 289 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(290);


/***/ }),
/* 290 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(291);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),
/* 291 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(292)
)

/* script */
__vue_exports__ = __webpack_require__(293)

/* template */
var __vue_template__ = __webpack_require__(294)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/src/task/detail/App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-1e0dd0c4"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 292 */
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "task-detail": {
    "position": "relative"
  },
  "detail": {
    "position": "absolute",
    "top": 0,
    "left": 0,
    "right": 0,
    "bottom": 0
  },
  "empty": {
    "height": "326"
  },
  "task-img": {
    "width": "750",
    "height": "750"
  },
  "user": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "height": "74",
    "paddingTop": "0",
    "paddingRight": "30",
    "paddingBottom": "26",
    "paddingLeft": "30"
  },
  "user-img": {
    "width": "74",
    "height": "74",
    "borderRadius": "8"
  },
  "user-info": {
    "flex": 1,
    "flexDirection": "column",
    "justifyContent": "space-between",
    "paddingLeft": "16",
    "height": "74"
  },
  "user-name": {
    "fontSize": "32",
    "lineHeight": "32",
    "color": "#ffffff"
  },
  "user-distance": {
    "fontSize": "28",
    "lineHeight": "28",
    "color": "#ffffff"
  },
  "content": {
    "marginTop": "26",
    "backgroundColor": "#ffffff",
    "borderTopLeftRadius": "15",
    "borderTopRightRadius": "15"
  },
  "content-detail": {
    "paddingTop": "30",
    "paddingRight": "30",
    "paddingBottom": "40",
    "paddingLeft": "30"
  },
  "topic": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignContent": "flex-start",
    "paddingBottom": "43",
    "borderBottomWidth": "1",
    "borderBottomColor": "#dfdfdf"
  },
  "topic-info": {
    "flex": 1
  },
  "topic-icon": {
    "width": "34",
    "lineHeight": "44"
  },
  "title": {
    "fontSize": "34",
    "color": "#3f3453",
    "fontWeight": "700"
  },
  "bounty": {
    "fontSize": "32",
    "color": "#db57bf",
    "paddingTop": "12",
    "paddingRight": "0",
    "paddingBottom": "11",
    "paddingLeft": "0",
    "fontWeight": "700"
  },
  "completion": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignContent": "center"
  },
  "completion-text": {
    "fontSize": "24",
    "color": "#beb8c4",
    "lineHeight": "40"
  },
  "line": {
    "paddingTop": "0",
    "paddingRight": "15",
    "paddingBottom": "0",
    "paddingLeft": "15"
  },
  "completion-btn": {
    "flex": 1,
    "textAlign": "right",
    "fontSize": "30",
    "color": "#6f4efa"
  },
  "require": {
    "fontSize": "30",
    "color": "#9b94a1",
    "paddingTop": "39",
    "paddingRight": "12",
    "paddingBottom": "0",
    "paddingLeft": "28"
  },
  "group": {
    "paddingTop": "40",
    "paddingRight": "30",
    "paddingBottom": "40",
    "paddingLeft": "30",
    "borderTopWidth": "1",
    "borderTopColor": "#dfdfdf",
    "borderBottomWidth": "1",
    "borderBottomColor": "#dfdfdf"
  },
  "group-text": {
    "fontSize": "30",
    "color": "#beb8c4",
    "paddingBottom": "16"
  },
  "user-list": {
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignContent": "center",
    "alignItems": "center"
  },
  "list-img": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignContent": "center",
    "alignItems": "center"
  },
  "user-list-img": {
    "width": "72",
    "height": "72",
    "borderRadius": "8",
    "marginRight": "10"
  },
  "group-btn": {
    "flex": 1,
    "justifyContent": "flex-end"
  },
  "remuneration": {
    "paddingTop": "40",
    "paddingRight": "30",
    "paddingBottom": "40",
    "paddingLeft": "58"
  },
  "remuneration-list": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignContent": "center",
    "alignItems": "center",
    "paddingBottom": "16"
  },
  "remuneration-title": {
    "width": "192",
    "lineHeight": "56",
    "fontSize": "30",
    "color": "#9b94a1"
  },
  "remuneration-detail": {
    "flex": 1,
    "fontSize": "30",
    "color": "#3f3453"
  }
}

/***/ }),
/* 293 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _native = __webpack_require__(13);

var _native2 = _interopRequireDefault(_native);

var _url = __webpack_require__(14);

var _url2 = _interopRequireDefault(_url);

var _components2 = __webpack_require__(16);

var _utils = __webpack_require__(15);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable */


var modal = weex.requireModule('modal');
var navigator = weex.requireModule('wb-navigator');
var nativeChat = weex.requireModule('wb-nativerouter');

var attender_status = {
  finish: '已结束',
  processing: '完成任务', // 进行中
  idle: '参加任务' // 未参加
};

exports.default = {
  name: 'App',
  components: _defineProperty({}, _components2.AiButton.name, _components2.AiButton),
  data: function data() {
    return {
      id: 0,
      distance: 0,
      detail: null
    };
  },

  computed: {
    // 总酬金
    totalFee: function totalFee() {
      var reward = parseFloat(this.detail.single_reward || 0);
      var nums = parseFloat(this.detail.user_nums || 0);
      var fee = reward * nums;
      return fee;
    }
  },
  created: function created() {
    // 接任务id
    var params = _native2.default.router.getParams();
    this.id = params.id;
    // this.id = 17
    if (this.id) {
      this.query();
    }
  },

  methods: {
    // address() {
    //   native.router.open({
    //     url: 'task/address.js'
    //   })
    // },
    getButtonText: function getButtonText() {
      return attender_status[this.detail.attender_status];
    },

    // 聊天/群聊
    singleChat: function singleChat() {
      var _this = this;

      if (!this.detail.is_group) {
        // 进入聊天 陌生人聊天
        this.chat(this.detail.user.id, this.detail.user.name, 1);
      } else {
        // 群聊 先申请进群
        var option = {
          url: _url2.default.joinGroup,
          method: 'post',
          params: {
            group_id: this.detail.group.id
          }
        };
        _native2.default.loading.show();
        _native2.default.network(option).then(function () {
          _native2.default.loading.hide();
          // 进入聊天
          _this.chat(_this.detail.group.id, _this.detail.group.group_name, 3);
        }).catch(function () {
          _native2.default.loading.hide();
        });
      }
    },

    // 参加任务
    joinTask: function joinTask() {
      // 发布者
      if (this.detail.is_creator) return;
      // 如果任务已经结束
      if (this.detail.attender_status == 'finish') return;
      _native2.default.loading.show();
      if (!this.detail.is_group) {
        this.single();
      } else {
        this.group();
      }
    },

    // 关注作者，发起任务申请
    single: function single() {
      var _this2 = this;

      var option = {
        url: _url2.default.changeFriends,
        method: 'post',
        params: {
          friend_id: this.detail.user.id
        }
      };
      _native2.default.network(option).then(function () {
        if (_this2.detail.attender_status === 'idle') {
          // 申请任务
          _native2.default.network({
            url: _url2.default.applyTask,
            method: 'post',
            params: {
              task_id: _this2.detail.id
            }
          }).then(function (res) {
            _native2.default.loading.hide();
            // 发送消息
            _this2.sendMessage({
              type: 1,
              taskType: 1,
              targetId: _this2.detail.user.id,
              targetName: _this2.detail.user.name,
              taskId: _this2.detail.id,
              taskApplyId: res.task_apply_id, // 申请任务成功后的申请id
              taskMemberId: '',
              taskDesc: _this2.detail.task_name,
              taskIcon: _this2.detail.video.video_cover
            });
          }).catch(function () {
            _native2.default.loading.hide();
          });
        } else {
          _native2.default.loading.hide();
          // 发送消息
          _this2.sendMessage({
            type: 1,
            taskType: 4,
            targetId: _this2.detail.user.id,
            targetName: _this2.detail.user.name,
            taskId: _this2.detail.id,
            taskApplyId: '', // 申请任务成功后的申请id
            taskMemberId: _this2.detail.task_member_id,
            taskDesc: _this2.detail.task_name,
            taskIcon: _this2.detail.video.video_cover
          });
        }
      }).catch(function () {
        _native2.default.loading.hide();
      });
    },

    // 申请进群，发起任务申请
    group: function group() {
      var _this3 = this;

      var option = {
        url: _url2.default.joinGroup,
        method: 'post',
        params: {
          group_id: this.detail.group.id
        }
      };
      _native2.default.network(option).then(function () {
        // 发送申请任务
        if (_this3.detail.attender_status === 'idle') {
          // 未参加任务状态
          _native2.default.network({
            url: _url2.default.applyTask,
            method: 'post',
            params: {
              task_id: _this3.detail.id
            }
          }).then(function (res) {
            _native2.default.loading.hide();
            // 发送消息 此处包含申请任务消息和申请完成任务消息
            // this.detail.attender_status == 'processing' -- 进行中
            // modal.toast({
            //   message: `${res.task_apply_id}`,
            //   duration: 0.3
            // })
            _this3.sendMessage({
              type: 3,
              taskType: 1,
              targetId: _this3.detail.group.id,
              targetName: _this3.detail.group.group_name,
              taskId: _this3.detail.id,
              taskApplyId: res.task_apply_id, // 申请任务成功后的申请id
              taskMemberId: '',
              taskDesc: _this3.detail.task_name,
              taskIcon: _this3.detail.video.video_cover
            });
          }).catch(function () {
            _native2.default.loading.hide();
          });
        } else {
          _native2.default.loading.hide();
          _this3.sendMessage({
            type: 3,
            taskType: 4,
            targetId: _this3.detail.group.id,
            targetName: _this3.detail.group.group_name,
            taskId: _this3.detail.id,
            taskApplyId: '', // 申请任务成功后的申请id
            taskMemberId: _this3.detail.task_member_id,
            taskDesc: _this3.detail.task_name,
            taskIcon: _this3.detail.video.video_cover
          });
        }
      }).catch(function () {
        _native2.default.loading.hide();
      });
    },

    // 发送消息
    sendMessage: function sendMessage(params) {
      var _this4 = this;

      nativeChat.sendMessage({
        name: 'HM:TaskCustom',
        conversationType: params.type, // 1单聊 3群聊
        params: {
          taskType: params.taskType, // 1任务申请 2任务许可 3同意添加 4完成任务 5确认完成
          targetId: params.targetId, // 用户/群id
          taskId: params.taskId, // 任务id
          taskApplyId: params.taskApplyId, // 申请任务成功后的申请id
          taskMemberId: params.taskMemberId, // 作者审核成功后的id
          taskDesc: params.taskDesc, // 任务标题
          taskIcon: params.taskIcon // 视频封面图
        }
      }, function (result) {
        if (result.status === 0) {
          // 进入聊天
          _this4.chat(params.targetId, params.targetName, params.type);
        }
      });
    },

    // 聊天
    chat: function chat(id, name, type) {
      nativeChat.open({
        name: 'chatCommand',
        params: {
          targetId: id, // 用户/群id
          userName: name, // 用户/群名称
          conversationType: type // 3:群聊 1:单聊
        }
      });
    },
    progress: function progress(taskId) {
      _native2.default.router.open({
        url: 'task/progress.js',
        params: {
          taskId: taskId
        }
      });
    },

    // 获取还剩多少小时
    getSurplusTime: function getSurplusTime(end) {
      var start = new Date().getTime();
      return _utils2.default.dateToHour(start, end);
    },

    // 设置距离
    getLocation: function getLocation() {
      var _this5 = this;

      _native2.default.location.then(function (res) {
        var firstDistance = {
          lon: res.lon,
          lat: res.lat
        };
        var secondDistance = {
          lon: _this5.detail.longitude,
          lat: _this5.detail.latitude
        };
        _this5.distance = _utils2.default.getDistance(firstDistance, secondDistance);
      }).catch(function () {
        _this5.distance = ' 未知';
      });
    },
    getEndTime: function getEndTime(date) {
      return _utils2.default.dataToString('y-m-d h:i:s', date * 1000);
    },
    query: function query() {
      var _this6 = this;

      // modal.toast({
      //   message: `id=${this.id}`,
      //   duration: 0.3
      // })
      var params = {
        url: 'api/task/detail?id=' + this.id,
        method: 'get',
        params: {}
      };
      _native2.default.network(params).then(function (data) {
        _this6.detail = data;
        navigator.setCenterItem({
          text: data.user_name + '\u7684\u4EFB\u52A1',
          color: '3F3453'
        }, function () {});
        _this6.getLocation();
      }).catch(function () {});
    }
  }
};

/***/ }),
/* 294 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (_vm.detail) ? _c('div', {
    staticClass: ["task-detail"]
  }, [_c('image', {
    staticClass: ["task-img"],
    attrs: {
      "resize": "cover",
      "src": _vm.detail.video.video_cover
    }
  }), _c('div', {
    staticClass: ["detail"]
  }, [_c('scroller', [_c('div', {
    staticClass: ["empty"]
  }), _c('div', {
    staticClass: ["user"]
  }, [_c('image', {
    staticClass: ["user-img"],
    attrs: {
      "src": _vm.detail.user.avatar
    }
  }), _c('div', {
    staticClass: ["user-info"]
  }, [_c('text', {
    staticClass: ["user-name"]
  }, [_vm._v(_vm._s(_vm.detail.user_name))]), _c('text', {
    staticClass: ["user-distance"]
  }, [_vm._v("距离位置" + _vm._s(_vm.distance))])])]), _c('div', {
    staticClass: ["content"]
  }, [_c('div', {
    staticClass: ["content-detail"]
  }, [_c('div', {
    staticClass: ["topic"]
  }, [_c('text', {
    staticClass: ["topic-icon", "title"]
  }, [_vm._v("#")]), _c('div', {
    staticClass: ["topic-info"]
  }, [_c('text', {
    staticClass: ["title"]
  }, [_vm._v(_vm._s(_vm.detail.task_name))]), _c('text', {
    staticClass: ["bounty"]
  }, [_vm._v("赏金 " + _vm._s(_vm.detail.single_reward) + "积分")]), _c('div', {
    staticClass: ["completion"]
  }, [_c('text', {
    staticClass: ["completion-text"]
  }, [_vm._v(_vm._s(_vm.detail.has_nums) + "人参加")]), _c('text', {
    staticClass: ["completion-text", "line"]
  }, [_vm._v("|")]), _c('text', {
    staticClass: ["completion-text"]
  }, [_vm._v(_vm._s(_vm.detail.finish_nums) + "人已经完成")]), _c('text', {
    staticClass: ["completion-text", "line"]
  }, [_vm._v("|")]), _c('text', {
    staticClass: ["completion-text"]
  }, [_vm._v("还剩" + _vm._s(_vm.getSurplusTime(_vm.detail.end_at * 1000)))]), _c('text', {
    staticClass: ["completion-btn"],
    on: {
      "click": function($event) {
        _vm.progress(_vm.detail.id)
      }
    }
  }, [_vm._v("任务进展")])])])]), _c('text', {
    staticClass: ["require"]
  }, [_vm._v(_vm._s(_vm.detail.task_required))])]), _c('div', {
    staticClass: ["group"]
  }, [_c('text', {
    staticClass: ["group-text"]
  }, [_vm._v(_vm._s(_vm.detail.video.interested_user.length) + "人对这个任务感兴趣")]), _c('div', {
    staticClass: ["user-list"]
  }, [_c('div', {
    staticClass: ["list-img"]
  }, _vm._l((_vm.detail.video.interested_user), function(item) {
    return _c('image', {
      staticClass: ["user-list-img"],
      attrs: {
        "src": item.avatar
      }
    })
  })), (!_vm.detail.is_creator || _vm.detail.is_group) ? _c('ai-button', {
    attrs: {
      "text": _vm.detail.is_group ? '群聊' : '聊天',
      "type": "primary",
      "size": "small"
    },
    on: {
      "click": _vm.singleChat
    }
  }) : _vm._e()], 1)]), _c('div', {
    staticClass: ["remuneration"]
  }, [_c('div', {
    staticClass: ["remuneration-list"]
  }, [_c('text', {
    staticClass: ["remuneration-title"]
  }, [_vm._v("总酬金")]), _c('text', {
    staticClass: ["remuneration-detail"]
  }, [_vm._v(_vm._s(_vm.detail.single_reward) + "积分 x " + _vm._s(_vm.detail.user_nums) + "次 = " + _vm._s(_vm.totalFee) + "积分")])]), _c('div', {
    staticClass: ["remuneration-list"]
  }, [_c('text', {
    staticClass: ["remuneration-title"]
  }, [_vm._v("参与次数")]), _c('text', {
    staticClass: ["remuneration-detail"]
  }, [_vm._v("最大" + _vm._s(_vm.detail.user_nums) + "人")])]), _c('div', {
    staticClass: ["remuneration-list"]
  }, [_c('text', {
    staticClass: ["remuneration-title"]
  }, [_vm._v("截止时间")]), _c('text', {
    staticClass: ["remuneration-detail"]
  }, [_vm._v(_vm._s(_vm.getEndTime(_vm.detail.end_at)))])])])])]), (!_vm.detail.is_creator) ? _c('ai-button', {
    attrs: {
      "text": _vm.getButtonText(),
      "type": "primary",
      "btnStyle": {
        width: '750px',
        height: '100px'
      },
      "textStyle": {
        fontWeight: '700'
      },
      "disabled": _vm.detail.attender_status == 'finish',
      "radius": false,
      "size": "large"
    },
    on: {
      "click": _vm.joinTask
    }
  }) : _vm._e()], 1)]) : _vm._e()
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })
/******/ ]);