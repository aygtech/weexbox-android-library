// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 465);
/******/ })
/************************************************************************/
/******/ ({

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var modal = weex.requireModule('modal');
var _network = weex.requireModule('wb-network');
var _router = weex.requireModule('wb-router');
var _location = weex.requireModule('wb-location');
var _modal = weex.requireModule('wb-modal');
var _nativerouter = weex.requireModule('wb-nativerouter');

// const _network = (option, cb) => {
//   setTimeout(() => {
//     cb(option)
//   }, 2000)
// }

// 获取工具栏高度
var toolbar = {
  /**
   * 工具栏高度
   */
  height: function height() {
    var env = weex.config.env;

    var height = _nativerouter.nativeNavigationHeight() / env.deviceWidth * 750;
    return Math.ceil(height);
  }
};

// 加载动画
var loading = {
  /**
   * 打开菊花
   * @param {String} text - 参数
   */
  show: function show(text) {
    _modal.showLoading(text || '加载中...');
  },

  /**
   * 关闭菊花
   */
  hide: function hide() {
    _modal.dismiss();
  }
};

/**
 * 网络请求
 * @param {object} option - 参数
 * @param {string} option.url - 服务器 URL.
 * @param {string} [option.method=get] - 创建请求时使用的方法
 * @param {object} [option.headers={ 'X-Requested-With': 'XMLHttpRequest' }] - 自定义请求头
 * @param {object} [option.params={}] - 请求数据的参数
 * @returns {unknown} - 请求结果,待定
 */
var network = function network(option) {
  return new Promise(function (resolve, reject) {
    var _option = {
      url: null,
      method: 'get',
      // headers: { 'X-Requested-With': 'XMLHttpRequest' },
      params: {}
    };
    var param = Object.assign(_option, option);

    param.method = param.method.toLowerCase();
    console.log('pafram---:' + JSON.stringify(param));
    console.log('url---:' + param.url);
    _network.request(param, function (result) {
      if (result.status === 401) {
        // 原生处理，跳转到登录
        console.log('登录问题，原生处理');
        console.log(result);
        modal.toast({
          message: '401--' + result.error,
          duration: 2
        });
        return;
      }
      // 原生
      // result.status http请求状态码，成功返回200
      // result.error 错误信息
      // result.data 服务器返回的对象

      // 服务器
      // result.data.code:0 成功
      // result.data.code:10001 权限不足
      // result.data.message 成功 >'ok' 异常 > 异常信息
      // result.data.data 服务器返回数据

      if (result.status === 200) {
        if (result.data.code === 0 || result.data.code === '0') {
          resolve(result.data.data);
          console.log('\u8BF7\u6C42\u6210\u529F url:' + param.url);
          console.log(result);
        } else {
          modal.toast({
            message: '\u6570\u636E\u5F02\u5E38--' + JSON.stringify(result.data.message),
            duration: 10
          });
          console.log('数据异常');
          console.error(result);

          reject(result);
        }
      } else {
        modal.toast({
          message: '\u8BF7\u6C42\u51FA\u9519--' + JSON.stringify(result.error) + ' status - ' + result.status,
          duration: 10
        });

        console.log('请求出错');
        console.error(result);

        reject(result);
      }
    });
  });
};

// 页面路由
var router = {
  /**
   * 打开页面
   * @param {object} option - 参数
   * @param {string} option.url - 下一个weex/web的路径
   * @param {string} [option.name] - 页面名称。内置"weex"、"web"，其他路由需要原生先注册
   * @param {string} [option.type=push] - 下一个weex/web的路径
   * @param {boolean} [option.navBarHidden=false] - 是否隐藏导航栏
   * @param {object} [option.params={}] - // 需要传到下一个页面的数据
   */
  open: function open(option) {
    var _option = {
      name: 'weex',
      url: null,
      type: 'push',
      navBarHidden: false,
      params: {}
    };
    var param = Object.assign(_option, option);
    _router.open(param);
  },

  /**
   * 关闭页面
   * @param {string} [level=1] - 关闭页面的级数
   */
  close: function close() {
    var level = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

    _router.close(level);
  },

  /**
   * 刷新weex页面
   */
  refresh: function refresh() {
    _router.refresh();
  },

  /**
   * 获取页面参数
   */
  getParams: function getParams() {
    return _router.getParams();
  }
};

// 地理定位
var location = new Promise(function (resolve, reject) {
  _location.getLocation(function (result) {
    if (result.status === 0) {
      resolve(result.data);
    } else {
      reject(result);
    }
  });
});

exports.default = {
  network: network,
  router: router,
  location: location,
  loading: loading,
  toolbar: toolbar
};

/***/ }),

/***/ 14:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});


// const host = 'api'
var host = 'http://iquest-test94.aiyuangong.com/api';
/* 接口类别 */
// 任务
var task = host + '/task';

// 好友
var friends = host + '/friends';

// 个人信息
var user = host + '/user';

// 群组
var group = host + '/group';

// 评价
var account = host + '/account';

// 账户
var personal = host + '/personal';

/* eslint-disable no-new */
exports.default = {
  /**
   * 任务
   */

  // 任务-申请任务
  applyTask: task + '/apply',
  // 任务首页 推荐列表
  taskRecommendList: task + '/special/recommendList',
  // 任务首页 最新列表
  taskNewestList: task + '/special/recommendList',
  // 任务首页 附近列表
  taskNearList: task + '/special/recommendList',
  // 任务首页 信用列表
  taskCreditList: task + '/special/recommendList',
  // 任务-过程-列表
  taskProcessList: task + '/processList',
  // 任务 同意参加任务
  taskApproval: task + '/approval',
  // 任务-详情
  taskDetail: task + '/detail',
  // 任务 完成任务列表
  attendList: task + '/attendList',
  // 任务 发布的任务列表
  publishList: task + '/publishList',
  // 任务 最近完成任务列表
  recentlyCompleteTaskList: host + '/personal/recentlyCompleteTaskList',
  // 任务 确认完成任务
  taskComplete: task + '/complete',
  // 任务 打分
  taskEvaluate: task + '/evaluate',
  // 任务 邀请打分
  taskeEaluation: task + '/evaluation',

  /**
   * 好友
   */

  // 好友—关注或者取消关注
  changeFriends: friends + '/changeFriends',
  // 好友-我关注列表(我关注的)
  followListPage: friends + '/followListPage',
  // 好友—获取粉丝列表(关注我的)
  fansListPage: friends + '/fansListPage',

  /**
   * 个人中心
   */

  // 个人信息
  getOne: user + '/getOne',
  // 编辑个人信息
  updateInfo: user + '/updateInfo',
  // 个人视频列表
  UserVideoPage: host + '/video/UserVideoPage',

  /*
  * 账户
  */
  // 冻结列表
  accountFreezeList: account + '/freezeList',
  // 收支记录列表
  accountDetailList: account + '/detailList',
  // 获取钱包余额
  accountBalance: account + '/balance',

  /*
  * 评价
  */
  personalEvaluateList: personal + '/evaluateList',

  /**
   * 群组
   */
  // 群组-创建群
  createGroup: group + '/createGroup',
  // 群组-获取用户加入的群列表
  GroupListPage: group + '/GroupListPage',
  // 群组-获取组成员信息
  getGroupMember: group + '/getGroupMember',
  // 群组-获取群成员列表（分页）
  GroupMemberListPage: group + '/GroupMemberListPage',
  // 群组-获取某一群组信息
  getGroupOne: group + '/getOne',
  // 群组-修改群组信息
  updateGroup: group + '/updateGroup',
  // 群组-邀请加入群
  inviteJoinGroup: group + '/inviteJoinGroup',
  // 群组-用户主动加入群
  joinGroup: group + '/joinGroup'
};

/***/ }),

/***/ 18:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(19)
)

/* script */
__vue_exports__ = __webpack_require__(20)

/* template */
var __vue_template__ = __webpack_require__(21)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-button/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-323437cf"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 19:
/***/ (function(module, exports) {

module.exports = {
  "small": {
    "width": "124",
    "height": "64"
  },
  "medium": {
    "width": "156",
    "height": "64"
  },
  "big": {
    "width": "560",
    "height": "80"
  },
  "large": {
    "width": "690",
    "height": "88"
  },
  "radius": {
    "borderRadius": "6"
  },
  "ai-btn": {
    "justifyContent": "center",
    "alignItems": "center"
  },
  "normal": {
    "backgroundColor": "#ffffff",
    "backgroundImage": "none",
    "borderColor": "#6f4efa",
    "borderWidth": "1"
  },
  "primary": {
    "backgroundColor": "#6f4efa",
    "backgroundImage": "linear-gradient(to right, #cc4def, #6f4efa)",
    "borderWidth": "0"
  },
  "text-primary": {
    "color": "#ffffff"
  },
  "clicked": {
    "backgroundColor": "#f6f7ff",
    "backgroundImage": "none",
    "borderColor": "#dfdfdf",
    "borderWidth": "1"
  },
  "text-clicked": {
    "color": "#6f4efa"
  },
  "disabled": {
    "backgroundColor": "#dfdfdf",
    "backgroundImage": "none"
  },
  "text-disabled": {
    "color": "#ffffff"
  },
  "btn-text": {
    "textAlign": "center",
    "color": "#6f4efa",
    "fontSize": "32"
  }
}

/***/ }),

/***/ 20:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'ai-button',
  props: {
    text: {
      type: String,
      default: '确认'
    },
    type: {
      type: String,
      default: 'normal'
    },
    size: {
      type: String,
      default: 'medium'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    radius: {
      type: Boolean,
      default: true
    },
    btnStyle: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    textStyle: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {};
  },

  methods: {
    onClicked: function onClicked(e) {
      var type = this.type,
          disabled = this.disabled;

      if (!disabled) {
        this.$emit('click', { e: e, type: type, disabled: disabled });
      }
    }
  }
};

/***/ }),

/***/ 21:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['ai-btn', _vm.radius && 'radius', _vm.size, _vm.type, _vm.disabled && 'disabled'],
    style: _vm.btnStyle,
    on: {
      "click": _vm.onClicked
    }
  }, [_c('text', {
    class: ['btn-text', _vm.disabled ? 'text-disabled' : ("text-" + _vm.type)],
    style: _vm.textStyle,
    on: {
      "click": _vm.onClicked
    }
  }, [_vm._v(_vm._s(_vm.text))]), _vm._t("default")], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 465:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(466);


/***/ }),

/***/ 466:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(467);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 467:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(468)
)

/* script */
__vue_exports__ = __webpack_require__(469)

/* template */
var __vue_template__ = __webpack_require__(471)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/src/user/wallet/App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-fb49cd34"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 468:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "page": {
    "backgroundColor": "#f4f4f4"
  },
  "top-image-box": {
    "justifyContent": "center",
    "alignItems": "center",
    "height": "466",
    "backgroundColor": "#ffffff"
  },
  "top-image": {
    "width": "374",
    "height": "366"
  },
  "btns-box": {
    "paddingLeft": "100",
    "paddingRight": "100",
    "paddingBottom": "90",
    "paddingTop": "10",
    "justifyContent": "space-between",
    "flexDirection": "row",
    "background": "#FFFFFF",
    "backgroundColor": "#ffffff",
    "marginBottom": "20"
  },
  "question-box": {
    "position": "absolute",
    "bottom": "34",
    "flexDirection": "row",
    "justifyContent": "center",
    "width": "750",
    "height": "70",
    "left": "0"
  },
  "top-text-box": {
    "position": "absolute",
    "width": "350",
    "height": "120",
    "left": 200,
    "top": 170,
    "alignItems": "center",
    "justifyContent": "space-between"
  }
}

/***/ }),

/***/ 469:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _iconWalletTitle = __webpack_require__(470);

var _iconWalletTitle2 = _interopRequireDefault(_iconWalletTitle);

var _index = __webpack_require__(18);

var _index2 = _interopRequireDefault(_index);

var _index3 = __webpack_require__(48);

var _index4 = _interopRequireDefault(_index3);

var _native = __webpack_require__(13);

var _native2 = _interopRequireDefault(_native);

var _url = __webpack_require__(14);

var _url2 = _interopRequireDefault(_url);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// const modal = weex.requireModule('modal')

var navigator = weex.requireModule('wb-navigator'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'wallet',
  components: {
    WBtn: _index2.default,
    WCell: _index4.default
  },
  data: function data() {
    return {
      topIcon: _iconWalletTitle2.default,
      money: 0
    };
  },
  created: function created() {
    navigator.setCenterItem({
      text: '钱包',
      color: '3f3453'
    }, function () {});
    this.getMoney();
  },

  methods: {
    getMoney: function getMoney() {
      var _this = this;

      var option = {
        url: _url2.default.accountBalance,
        method: 'get',
        params: {}
      };
      _native2.default.network(option).then(function (data) {
        _this.money = data.amount;
      }).catch(function () {});
    },

    // cell 点击
    cellClick: function cellClick(path) {
      _native2.default.router.open({
        url: path,
        params: {}
      });
    },

    // 常见问题按钮点击
    questionBtnClick: function questionBtnClick() {
      // native.router.open({
      //   url: path,
      //   params: {
      //   }
      // })
    }
  }
};

/***/ }),

/***/ 470:
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/icon-wallet-title_79a6433e0a37b872d4f22cd70c2deeea.png";

/***/ }),

/***/ 471:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["page"]
  }, [_c('div', {
    staticClass: ["top-image-box"]
  }, [_c('image', {
    staticClass: ["top-image"],
    attrs: {
      "src": _vm.topIcon
    }
  }), _c('div', {
    staticClass: ["top-text-box"]
  }, [_c('text', {
    staticStyle: {
      fontSize: "54px",
      color: "#FFFFFF"
    }
  }, [_vm._v(_vm._s(_vm.money))]), _c('text', {
    staticStyle: {
      fontSize: "28px",
      color: "#F6F7FF"
    }
  }, [_vm._v("可用积分")])])]), _c('div', {
    staticClass: ["btns-box"]
  }, [_c('w-btn', {
    attrs: {
      "type": "primary",
      "text": "充值",
      "btnStyle": {
        width: '238px'
      }
    }
  }), _c('w-btn', {
    attrs: {
      "text": "提现",
      "btnStyle": {
        width: '238px',
        backgroundColor: '#F6F7FF'
      }
    }
  })], 1), _c('w-cell', {
    style: {
      backgroundColor: '#f4f4f4'
    },
    attrs: {
      "label": "收支记录",
      "hasArrow": true
    },
    on: {
      "aiCellClick": function($event) {
        _vm.cellClick("user/walletRecord.js")
      }
    }
  }), _c('w-cell', {
    style: {
      backgroundColor: '#f4f4f4'
    },
    attrs: {
      "label": "冻结积分",
      "hasArrow": true
    },
    on: {
      "aiCellClick": function($event) {
        _vm.cellClick("user/freezingPoints.js")
      }
    }
  }), _c('div', {
    staticClass: ["question-box"]
  }, [_c('w-btn', {
    attrs: {
      "text": "常见问题",
      "textStyle": {
        color: '#9B94A1'
      },
      "btnStyle": {
        width: '238px',
        'borderColor': 'rgba(0,0,0,0)',
        backgroundColor: 'rgba(0,0,0,0)'
      }
    },
    on: {
      "click": function($event) {
        _vm.cellClick("user/commonProblems.js")
      }
    }
  })], 1)], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(49)
)

/* script */
__vue_exports__ = __webpack_require__(50)

/* template */
var __vue_template__ = __webpack_require__(52)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/mario/iQuest-APP/components/ai-cell/index.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-3233b67f"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 49:
/***/ (function(module, exports) {

module.exports = {
  "ai-cell": {
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center",
    "marginBottom": "1",
    "backgroundColor": "#ffffff"
  },
  "ai-cell-top-border": {
    "borderTopColor": "#dfdfdf",
    "borderTopWidth": "1"
  },
  "ai-cell-bottom-border": {
    "borderBottomColor": "#dfdfdf",
    "borderBottomWidth": "1"
  },
  "ai-cell-label-text": {
    "fontSize": "34",
    "color": "#3f3453",
    "width": "300",
    "marginRight": "10"
  },
  "ai-cell-arrow": {
    "marginLeft": "16"
  },
  "ai-cell-arrow-icon": {
    "width": "18",
    "height": "35"
  },
  "ai-cell-content": {
    "width": "400",
    "flex": 1
  },
  "ai-cell-content-text": {
    "fontSize": "34",
    "textAlign": "right",
    "color": "#665d76",
    "lines": 1,
    "textOverflow": "ellipsis"
  }
}

/***/ }),

/***/ 50:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _arrowRight = __webpack_require__(51);

var _arrowRight2 = _interopRequireDefault(_arrowRight);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'ai-cell',
  props: {
    label: {
      type: String,
      default: ''
    },
    content: {
      type: String,
      default: ''
    },
    hasArrow: {
      type: Boolean,
      default: false
    },
    arrowIcon: {
      type: String,
      default: _arrowRight2.default
    },
    topBorder: {
      type: Boolean,
      default: false
    },
    bottomBorder: {
      type: Boolean,
      default: true
    },
    paddingLeft: {
      type: [String, Number],
      default: '0'
    },
    paddingTop: {
      type: [String, Number],
      default: '20'
    },
    paddingBottom: {
      type: [String, Number],
      default: '20'
    },
    paddingRight: {
      type: [String, Number],
      default: '30'
    },
    marginLeft: {
      type: [String, Number],
      default: '30'
    },
    style: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  computed: {
    style: function style() {
      return {
        paddingLeft: this.paddingLeft + 'px',
        paddingTop: this.paddingTop + 'px',
        paddingBottom: this.paddingBottom + 'px',
        paddingRight: this.paddingRight + 'px',
        marginLeft: this.marginLeft + 'px'
      };
    }
  },
  data: function data() {
    return {};
  },

  watch: {},
  created: function created() {},

  methods: {
    aiCellClick: function aiCellClick() {
      this.$emit('aiCellClick');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 51:
/***/ (function(module, exports) {

module.exports = "http://iquest-test92.aiyuangong.com/hotdeploy/static/arrow-right_3f0be8615cd24e3d59831735259a5a50.png";

/***/ }),

/***/ 52:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['ai-cell', _vm.topBorder && 'ai-cell-top-border', _vm.bottomBorder && 'ai-cell-bottom-border'],
    style: _vm.style,
    on: {
      "click": _vm.aiCellClick
    }
  }, [_vm._t("label", [(_vm.label) ? _c('div', [_c('text', {
    staticClass: ["ai-cell-label-text"]
  }, [_vm._v(_vm._s(_vm.label))])]) : _vm._e()]), _vm._t("value"), (_vm.content) ? _c('div', {
    staticClass: ["ai-cell-content"]
  }, [_vm._t("content", [_c('text', {
    staticClass: ["ai-cell-content-text"]
  }, [_vm._v(_vm._s(_vm.content))])])], 2) : _vm._e(), (_vm.hasArrow) ? _c('div', {
    staticClass: ["ai-cell-arrow"]
  }, [_c('image', {
    staticClass: ["ai-cell-arrow-icon"],
    attrs: {
      "src": _vm.arrowIcon
    }
  })]) : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });