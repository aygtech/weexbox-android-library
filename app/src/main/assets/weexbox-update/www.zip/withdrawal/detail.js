// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 733);
/******/ })
/************************************************************************/
/******/ ({

/***/ 184:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/* eslint-disable */
/**
 * 获取文本长度 1个中午代表一个字符 一个英文代表半个字符
 * @return: Number
*/
var getStrLength = function getStrLength(str) {
  var len = 0;
  var charCode = -1;
  for (var i = 0; i < str.length; i += 1) {
    charCode = str.charCodeAt(i);
    if (charCode >= 0 && charCode <= 128) {
      // 英文
      len += 0.5;
    } else {
      // 中文
      len += 1;
    }
  }
  // 向上取整数
  return Math.ceil(len);
};

/**
 * 获取weex屏幕真实的设置高度
 * @return: Number
*/
var getScreenHeight = function getScreenHeight() {
  var env = weex.config.env;

  return env.deviceHeight / env.deviceWidth * 750;
};

/**
 * 时间戳转日期
 * @return: String
*/
function ceil(num) {
  return num < 10 ? '0' + num : num;
}
var dataToString = function dataToString(format) {
  var target = (arguments.length <= 1 ? 0 : arguments.length - 1) ? new Date(arguments.length <= 1 ? undefined : arguments[1]) : new Date();
  var rule = {
    y: target.getFullYear(),
    m: ceil(target.getMonth() + 1),
    d: ceil(target.getDate()),
    h: ceil(target.getHours()),
    i: ceil(target.getMinutes()),
    s: ceil(target.getSeconds()),
    w: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][target.getDay()]
  };

  return format.replace('y', rule.y).replace('m', rule.m).replace('d', rule.d).replace('h', rule.h).replace('i', rule.i).replace('s', rule.s).replace('w', rule.w);
};

/**
 * 日期转换 2018-10-23 16:10 转 2018/10/23 16:10
 * @return: String
*/
var transformDate = function transformDate(date) {
  var reg = new RegExp(/-/, 'g');
  var time = date.replace(reg, '/');
  return time;
};

/**
 * 转换数字 单位 万
 * @return: String
*/
var transformDigital = function transformDigital(num) {
  var dig = parseFloat(num);
  return dig < 10000 ? dig : (dig / 10000).toFixed(2) + 'w';
};

/**
 * 计算剩余时间
 * @param {Number} start - 开始时间戳 毫秒
 * @param {Number} end - 结束时间戳 毫秒
 * @return: String
*/
var dateToHour = function dateToHour(start, end) {
  var differ = end - start;
  // 结束时间小于开始时间
  if (differ <= 0) {
    return '0小时';
  }
  // 计算天数后剩余的小时数
  var ms = differ / (60 * 60 * 1000);
  var hours = Math.ceil(ms);
  return hours < 24 ? hours + '\u5C0F\u65F6' : Math.floor(hours / 24) + '\u5929' + hours % 24 + '\u5C0F\u65F6';
};

/**
 * 获取位置距离
 * @return: String
*/
var transformDistance = function transformDistance(distance) {
  var dis = parseFloat(distance);
  return dis < 1000 ? dis + 'm' : (dis / 1000).toFixed(2) + 'km';
};

/* eslint-disable */
/**
 * 计算两个经纬度之间距离
 * @param {Object} firstDistance - 开始时间戳 毫秒
 * @param {Object} secondDistance - 结束时间戳 毫秒
 * @param {Number} firstDistance.lat 经度
 * @param {Number} firstDistance.lon 纬度
 * @return: String
*/
var getDistance = function getDistance(firstDistance, secondDistance) {
  var radLat1 = parseFloat(firstDistance.lat) * Math.PI / 180.0;
  var radLat2 = parseFloat(secondDistance.lat) * Math.PI / 180.0;
  var a = radLat1 - radLat2;
  var b = parseFloat(firstDistance.lon) * Math.PI / 180.0 - parseFloat(firstDistance.lon) * Math.PI / 180.0;
  var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
  s = s * 6378.137; // EARTH_RADIUS;
  s = Math.round(s * 10000) / 10000;
  // 距离单位为km
  return s < 1 ? (s * 1000).toFixed(0) + 'm' : s.toFixed(2) + 'km';
};

/*
 * 时间格式化
*/
var dateFormat = function dateFormat(d) {
  var pattern = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

  if (!d) {
    return '';
  }
  var date = d;
  if (d instanceof Date) {
    date = d;
  } else {
    date = new Date(d);
  }
  if (!date) {
    return '';
  }
  var o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds(),
    'q+': Math.floor((date.getMonth() + 3) / 3),
    S: date.getMilliseconds()
  };
  if (/(y+)/.test(pattern)) {
    pattern = pattern.replace(RegExp.$1, ('' + date.getFullYear()).substr(4 - RegExp.$1.length));
  }

  for (var k in o) {
    if (new RegExp('(' + k + ')').test(pattern)) {
      pattern = pattern.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }
  }

  return pattern;
};

/**
 * 货币转中文单位
 * @param {String} unit - 接口返回货币单位
 */
var currencyToString = function currencyToString(unit) {
  var currency = {
    local: '积分',
    CNY: '元'
  };
  return currency[unit];
};
// const cn = {
//   local: {
//     text: '积分',
//     a: '积分'
//   },
//   cny: {
//     text: '元',
//     a: '金额'
//   }
// }

/*
 * 判断为空
*/
//去空
function trim(str) {
  return str.replace(/(^\s*)|(\s*$)/g, "");
}
var isEmpty = function isEmpty(str) {
  if (str == '' || str == null || (typeof str === 'undefined' ? 'undefined' : _typeof(str)) == undefined || str.length == 0 || trim(str).length == 0 || str == ' ') {
    return true;
  } else {
    return false;
  }
};

/*
 * 数组去重
*/
var unique = function unique(arr) {
  var ret = [];
  arr.reduce(function (prev, next) {
    prev[next] = prev[next] + 1 || 1;
    console.log(next);
    if (prev[next] === 1) ret.push(next);
    return prev;
  }, {});
  return ret;
};

/*
 * 判断字符串是否在数组中
 * params: {key:需要判断的字符串，arr：当前指定的数组}
 * result：{
 *     在: 删除
 *     否:添加到数组中}
*/
var in_array = function in_array(key, oldArr) {
  var arr = [].concat(oldArr);
  for (var i = 0; i < oldArr.length; i += 1) {
    if (arr[i] === key) {
      arr.splice(i, 1);
    }
  }
  arr.unshift(key);
  return arr;
};

exports.default = {
  getStrLength: getStrLength,
  getScreenHeight: getScreenHeight,
  transformDistance: transformDistance,
  getDistance: getDistance,
  dataToString: dataToString,
  transformDigital: transformDigital,
  dateToHour: dateToHour,
  dateFormat: dateFormat,
  currencyToString: currencyToString,
  isEmpty: isEmpty,
  unique: unique,
  in_array: in_array,
  transformDate: transformDate
};

/***/ }),

/***/ 22:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var modal = weex.requireModule('modal');
var _network = weex.requireModule('wb-network');
var _router = weex.requireModule('wb-router');
var _location = weex.requireModule('wb-location');
var _modal = weex.requireModule('wb-modal');
var _nativerouter = weex.requireModule('wb-nativerouter');

// const _network = (option, cb) => {
//   setTimeout(() => {
//     cb(option)
//   }, 2000)
// }

// 获取工具栏高度
var toolbar = {
  /**
   * 工具栏高度
   */
  height: function height() {
    var env = weex.config.env;

    var height = _nativerouter.nativeNavigationHeight() / env.deviceWidth * 750;
    return Math.ceil(height);
  }
};

// 加载动画
var loading = {
  /**
   * 打开菊花
   * @param {String} text - 参数
   */
  show: function show(text) {
    _modal.showLoading(text || '加载中...');
  },

  /**
   * 关闭菊花
   */
  hide: function hide() {
    _modal.dismiss();
  }
};

/**
 * 网络请求
 * @param {object} option - 参数
 * @param {string} option.url - 服务器 URL.
 * @param {string} [option.method=get] - 创建请求时使用的方法
 * @param {object} [option.headers={ 'X-Requested-With': 'XMLHttpRequest' }] - 自定义请求头
 * @param {object} [option.params={}] - 请求数据的参数
 * @returns {unknown} - 请求结果,待定
 */
var network = function network(option) {
  return new Promise(function (resolve, reject) {
    var _option = {
      url: null,
      method: 'get',
      // headers: { 'X-Requested-With': 'XMLHttpRequest' },
      params: {}
    };
    var param = Object.assign(_option, option);

    param.method = param.method.toLowerCase();
    console.log('===========================');
    console.log('\u5F00\u59CB\u8BF7\u6C42 url:' + param.url);
    console.log('pafram---:' + JSON.stringify(param));
    _network.request(param, function (result) {
      if (result.status === 401) {
        // 原生处理，跳转到登录
        console.log('登录问题，原生处理');
        console.log(result);
        modal.toast({
          message: result.error,
          duration: 1.5
        });
        return;
      }
      // 原生
      // result.status http请求状态码，成功返回200
      // result.error 错误信息
      // result.data 服务器返回的对象

      // 服务器
      // result.data.code:0 成功
      // result.data.code:10001 权限不足
      // result.data.message 成功 >'ok' 异常 > 异常信息
      // result.data.data 服务器返回数据

      if (result.status === 200) {
        if (result.data.code === 0 || result.data.code === '0') {
          resolve(result.data.data);
          console.log('\u8BF7\u6C42\u6210\u529F url:' + param.url);
          console.log(result);
          console.log('=========================');
        } else {
          loading.hide();
          modal.toast({
            message: result.data.message,
            duration: 1.5
          });
          console.log('数据异常');
          console.error(result);
          console.log('=========================');

          reject(result);
        }
      } else {
        modal.toast({
          message: result.error,
          duration: 1.5
        });

        console.log('请求出错');
        console.error(result);

        reject(result);
      }
    });
  });
};

// 页面路由
var router = {
  /**
   * 打开页面
   * @param {object} option - 参数
   * @param {string} option.url - 下一个weex/web的路径
   * @param {string} [option.name] - 页面名称。内置"weex"、"web"，其他路由需要原生先注册
   * @param {string} [option.type=push] - 下一个weex/web的路径
   * @param {boolean} [option.navBarHidden=false] - 是否隐藏导航栏
   * @param {object} [option.params={}] - // 需要传到下一个页面的数据
   */
  open: function open(option) {
    var _option = {
      name: 'weex',
      url: null,
      type: 'push',
      navBarHidden: false,
      params: {}
    };
    var param = Object.assign(_option, option);
    _router.open(param);
  },

  /**
   * 关闭页面
   * @param {string} [level=1] - 关闭页面的级数
   */
  close: function close() {
    var level = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

    _router.close(level);
  },

  /**
   * 刷新weex页面
   */
  refresh: function refresh() {
    _router.refresh();
  },

  /**
   * 获取页面参数
   */
  getParams: function getParams() {
    return _router.getParams();
  }
};

// 地理定位
var location = new Promise(function (resolve, reject) {
  _location.getLocation(function (result) {
    if (result.status === 0) {
      resolve(result.data);
    } else {
      reject(result);
    }
  });
});

exports.default = {
  network: network,
  router: router,
  location: location,
  loading: loading,
  toolbar: toolbar
};

/***/ }),

/***/ 733:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(734);


/***/ }),

/***/ 734:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(735);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 735:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(736)
)

/* script */
__vue_exports__ = __webpack_require__(737)

/* template */
var __vue_template__ = __webpack_require__(738)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "F:\\aiyuangong\\iQuest-APP\\src\\withdrawal\\detail\\App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-70b2bd67"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 736:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "bwrap-gray": {
    "backgroundColor": "#f7f7f7"
  },
  "detail": {
    "paddingTop": "10",
    "paddingRight": "0",
    "paddingBottom": "30",
    "paddingLeft": "30"
  },
  "list": {
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignContent": "center",
    "alignItems": "flex-start",
    "paddingTop": "22",
    "paddingRight": "30",
    "paddingBottom": "24",
    "paddingLeft": "0",
    "borderBottomWidth": "1",
    "borderBottomColor": "#e7e5e5"
  },
  "text": {
    "fontSize": "34",
    "lineHeight": "50"
  },
  "title": {
    "color": "#3d3d3d"
  },
  "info": {
    "color": "#6a6a6a"
  },
  "green": {
    "flex": 1,
    "textAlign": "right",
    "color": "#0BBE08"
  },
  "explain-panel": {
    "paddingTop": "30"
  },
  "explain-list": {
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "flexWrap": "wrap",
    "alignContent": "center",
    "alignItems": "flex-start"
  },
  "explain": {
    "fontSize": "24",
    "color": "#9e9e9e",
    "lineHeight": "33"
  },
  "explain-text": {
    "flex": 1
  },
  "yellow": {
    "color": "#ffb926"
  }
}

/***/ }),

/***/ 737:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _native = __webpack_require__(22);

var _native2 = _interopRequireDefault(_native);

var _utils = __webpack_require__(184);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var navigator = weex.requireModule('wb-navigator');

var channel = {
  alipay: '支付宝'
};
var status = {
  pending: '待处理',
  processing: '处理中',
  finish: '成功',
  failed: '失败'
};

exports.default = {
  name: 'record',
  components: {},
  data: function data() {
    return {
      status: status,
      channel: channel,
      detail: null
    };
  },
  created: function created() {
    navigator.setCenterItem({
      text: '提现记录',
      color: '3f3453'
    }, function () {});
    // 提现详情
    var params = _native2.default.router.getParams();
    if (params) {
      this.detail = params.detail;
    }
  },

  methods: {
    currencyToString: function currencyToString(unit) {
      return _utils2.default.currencyToString(unit);
    },
    getTime: function getTime(date) {
      return _utils2.default.dataToString('y-m-d h:i:s', date * 1000);
    }
  }
};

/***/ }),

/***/ 738:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (_vm.detail) ? _c('div', {
    staticClass: ["detail"]
  }, [_c('div', {
    staticClass: ["list"]
  }, [_c('text', {
    staticClass: ["text", "title"]
  }, [_vm._v("申请提现时间")]), _c('text', {
    staticClass: ["text", "info"]
  }, [_vm._v(_vm._s(_vm.getTime(_vm.detail.created_at)))])]), _c('div', {
    staticClass: ["list"]
  }, [_c('text', {
    staticClass: ["text", "title"]
  }, [_vm._v("金额")]), _c('text', {
    staticClass: ["text", "green"]
  }, [_vm._v(_vm._s(_vm.detail.amount))]), _c('text', {
    staticClass: ["text", "info"]
  }, [_vm._v(_vm._s(_vm.currencyToString(_vm.detail.currency_symbol)))])]), _c('div', {
    staticClass: ["list"]
  }, [_c('text', {
    staticClass: ["text", "title"]
  }, [_vm._v("提现到")]), _c('text', {
    staticClass: ["text", "info"]
  }, [_vm._v(_vm._s(_vm.channel[_vm.detail.remote_channel]))])]), _c('div', {
    staticClass: ["list"]
  }, [_c('text', {
    staticClass: ["text", "title"]
  }, [_vm._v("到账时间")]), _c('text', {
    staticClass: ["text", "info"]
  }, [_vm._v(_vm._s(_vm.getTime(_vm.detail.suppose_at)))])]), _c('div', {
    staticClass: ["list"]
  }, [_c('text', {
    staticClass: ["text", "title"]
  }, [_vm._v("最新状态")]), _c('text', {
    staticClass: ["text", "green"]
  }, [_vm._v(_vm._s(_vm.status[_vm.detail.status]))])]), _vm._m(0)]) : _vm._e()
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["explain-panel"]
  }, [_c('text', {
    staticClass: ["explain"]
  }, [_vm._v("说明：")]), _c('div', {
    staticClass: ["explain-list"]
  }, [_c('text', {
    staticClass: ["explain"]
  }, [_vm._v("1、")]), _c('text', {
    staticClass: ["explain", "explain-text"]
  }, [_vm._v("申请提现后，视提现渠道不同到账时间可能有1~3天的延迟；")])]), _c('div', {
    staticClass: ["explain-list"]
  }, [_c('text', {
    staticClass: ["explain"]
  }, [_vm._v("2、")]), _c('text', {
    staticClass: ["explain", "explain-text"]
  }, [_vm._v("请及时关注提现渠道的进账记录；")])]), _c('div', {
    staticClass: ["explain-list"]
  }, [_c('text', {
    staticClass: ["explain"]
  }, [_vm._v("3、")]), _c('div', {
    staticClass: ["explain-list", "explain-text"]
  }, [_c('text', {
    staticClass: ["explain"]
  }, [_vm._v("若提现发生异常，客服人员将通过官方服务号")]), _c('text', {
    staticClass: ["explain", "yellow"]
  }, [_vm._v(" 提现小助手 ")]), _c('text', {
    staticClass: ["explain"]
  }, [_vm._v("或者")]), _c('text', {
    staticClass: ["explain", "yellow"]
  }, [_vm._v(" 电话方式 ")]), _c('text', {
    staticClass: ["explain"]
  }, [_vm._v("与您联系，请勿轻信他人；")])])]), _c('div', {
    staticClass: ["explain-list"]
  }, [_c('text', {
    staticClass: ["explain"]
  }, [_vm._v("4、")]), _c('text', {
    staticClass: ["explain", "explain-text"]
  }, [_vm._v("客服不会要求您向任何账号转账或支付手续费。")])])])
}]}
module.exports.render._withStripped = true

/***/ })

/******/ });