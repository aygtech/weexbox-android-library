// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 569);
/******/ })
/************************************************************************/
/******/ ({

/***/ 569:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(570);


/***/ }),

/***/ 570:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(571);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 571:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(572)
)

/* script */
__vue_exports__ = __webpack_require__(573)

/* template */
var __vue_template__ = __webpack_require__(574)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "F:\\aiyuangong\\iQuest-APP\\src\\task\\help\\App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-4a993572"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 572:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "bwrap-gray": {
    "backgroundColor": "#f7f7f7"
  },
  "help": {
    "backgroundColor": "#f7f7f7"
  },
  "content": {
    "paddingTop": "30",
    "paddingRight": "20",
    "paddingBottom": "30",
    "paddingLeft": "30"
  },
  "text": {
    "lineHeight": "52",
    "fontSize": "32",
    "color": "#6a6a6a",
    "marginBottom": "25"
  }
}

/***/ }),

/***/ 573:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//

var navigator = weex.requireModule('wb-navigator');

exports.default = {
  name: 'App',
  components: {},
  data: function data() {
    return {};
  },

  computed: {},
  created: function created() {
    navigator.setCenterItem({
      text: '怎样发布任务',
      color: '3F3453'
    }, function () {});
  },

  methods: {}
};

/***/ }),

/***/ 574:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["help"]
  }, [_c('div', {
    staticClass: ["content"]
  }, [_c('text', {
    staticClass: ["text"]
  }, [_vm._v("使用爱收入，你可以通过简单的几个步骤就可以发布一个任务，只要悬赏出合理的赏金，就有机会寻找到合适的人选。当然，如果发布的任务对地理位置有要求，任务地点附近的爱收入用户数将会影响这个任务是否受欢迎。")]), _c('text', {
    staticClass: ["text"]
  }, [_vm._v("发布任务，首先需要拍摄一段视频。可以使用爱收入自带的拍摄功能拍摄一段15秒的视频，也可以从手机相册里选择一个已经编辑好的视频，通过这个视频，让你的任务要求得到充分的展示，以吸引更多合适的人对这个任务感兴趣。")]), _c('text', {
    staticClass: ["text"]
  }, [_vm._v("接下来，为任务设置一个简单易懂的标题，填写相关任务信息，设置赏金和任务类型，根据系统的引导完成一些设定后，任务就可以发布出来。发布后的任务将根据发布时间、地理位置、人气、参与度等因素进行推送，我们力争让一个优质任务得到更多人的观看与关注。")]), _c('text', {
    staticClass: ["text"]
  }, [_vm._v("当然，请不要使用爱收入发布违反公序良俗、法律法规的任务。我们会对发布的任务进行过滤及审核，平台的用户也会对一些不良内容进行举报。不良的内容可能直接遭到删除，甚至我们会通过报案的方式将相关资料提交给公安部门。")]), _c('text', {
    staticClass: ["text"]
  }, [_vm._v("若在使用过程中有任何想法，欢迎向我们提出你的宝贵意见。可以在聊天列表里找到官方客服号进行留言，我们会结合产品的特性做出改进。")])])])
}]}
module.exports.render._withStripped = true

/***/ })

/******/ });