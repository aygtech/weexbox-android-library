// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 621);
/******/ })
/************************************************************************/
/******/ ({

/***/ 184:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/* eslint-disable */
/**
 * 获取文本长度 1个中午代表一个字符 一个英文代表半个字符
 * @return: Number
*/
var getStrLength = function getStrLength(str) {
  var len = 0;
  var charCode = -1;
  for (var i = 0; i < str.length; i += 1) {
    charCode = str.charCodeAt(i);
    if (charCode >= 0 && charCode <= 128) {
      // 英文
      len += 0.5;
    } else {
      // 中文
      len += 1;
    }
  }
  // 向上取整数
  return Math.ceil(len);
};

/**
 * 获取weex屏幕真实的设置高度
 * @return: Number
*/
var getScreenHeight = function getScreenHeight() {
  var env = weex.config.env;

  return env.deviceHeight / env.deviceWidth * 750;
};

/**
 * 时间戳转日期
 * @return: String
*/
function ceil(num) {
  return num < 10 ? '0' + num : num;
}
var dataToString = function dataToString(format) {
  var target = (arguments.length <= 1 ? 0 : arguments.length - 1) ? new Date(arguments.length <= 1 ? undefined : arguments[1]) : new Date();
  var rule = {
    y: target.getFullYear(),
    m: ceil(target.getMonth() + 1),
    d: ceil(target.getDate()),
    h: ceil(target.getHours()),
    i: ceil(target.getMinutes()),
    s: ceil(target.getSeconds()),
    w: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][target.getDay()]
  };

  return format.replace('y', rule.y).replace('m', rule.m).replace('d', rule.d).replace('h', rule.h).replace('i', rule.i).replace('s', rule.s).replace('w', rule.w);
};

/**
 * 日期转换 2018-10-23 16:10 转 2018/10/23 16:10
 * @return: String
*/
var transformDate = function transformDate(date) {
  var reg = new RegExp(/-/, 'g');
  var time = date.replace(reg, '/');
  return time;
};

/**
 * 转换数字 单位 万
 * @return: String
*/
var transformDigital = function transformDigital(num) {
  var dig = parseFloat(num);
  return dig < 10000 ? dig : (dig / 10000).toFixed(2) + 'w';
};

/**
 * 计算剩余时间
 * @param {Number} start - 开始时间戳 毫秒
 * @param {Number} end - 结束时间戳 毫秒
 * @return: String
*/
var dateToHour = function dateToHour(start, end) {
  var differ = end - start;
  // 结束时间小于开始时间
  if (differ <= 0) {
    return '0小时';
  }
  // 计算天数后剩余的小时数
  var ms = differ / (60 * 60 * 1000);
  var hours = Math.ceil(ms);
  return hours < 24 ? hours + '\u5C0F\u65F6' : Math.floor(hours / 24) + '\u5929' + hours % 24 + '\u5C0F\u65F6';
};

/**
 * 获取位置距离
 * @return: String
*/
var transformDistance = function transformDistance(distance) {
  var dis = parseFloat(distance);
  return dis < 1000 ? dis + 'm' : (dis / 1000).toFixed(2) + 'km';
};

/* eslint-disable */
/**
 * 计算两个经纬度之间距离
 * @param {Object} firstDistance - 开始时间戳 毫秒
 * @param {Object} secondDistance - 结束时间戳 毫秒
 * @param {Number} firstDistance.lat 经度
 * @param {Number} firstDistance.lon 纬度
 * @return: String
*/
var getDistance = function getDistance(firstDistance, secondDistance) {
  var radLat1 = parseFloat(firstDistance.lat) * Math.PI / 180.0;
  var radLat2 = parseFloat(secondDistance.lat) * Math.PI / 180.0;
  var a = radLat1 - radLat2;
  var b = parseFloat(firstDistance.lon) * Math.PI / 180.0 - parseFloat(firstDistance.lon) * Math.PI / 180.0;
  var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
  s = s * 6378.137; // EARTH_RADIUS;
  s = Math.round(s * 10000) / 10000;
  // 距离单位为km
  return s < 1 ? (s * 1000).toFixed(0) + 'm' : s.toFixed(2) + 'km';
};

/*
 * 时间格式化
*/
var dateFormat = function dateFormat(d) {
  var pattern = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

  if (!d) {
    return '';
  }
  var date = d;
  if (d instanceof Date) {
    date = d;
  } else {
    date = new Date(d);
  }
  if (!date) {
    return '';
  }
  var o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds(),
    'q+': Math.floor((date.getMonth() + 3) / 3),
    S: date.getMilliseconds()
  };
  if (/(y+)/.test(pattern)) {
    pattern = pattern.replace(RegExp.$1, ('' + date.getFullYear()).substr(4 - RegExp.$1.length));
  }

  for (var k in o) {
    if (new RegExp('(' + k + ')').test(pattern)) {
      pattern = pattern.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }
  }

  return pattern;
};

/**
 * 货币转中文单位
 * @param {String} unit - 接口返回货币单位
 */
var currencyToString = function currencyToString(unit) {
  var currency = {
    local: '积分',
    CNY: '元'
  };
  return currency[unit];
};
// const cn = {
//   local: {
//     text: '积分',
//     a: '积分'
//   },
//   cny: {
//     text: '元',
//     a: '金额'
//   }
// }

/*
 * 判断为空
*/
//去空
function trim(str) {
  return str.replace(/(^\s*)|(\s*$)/g, "");
}
var isEmpty = function isEmpty(str) {
  if (str == '' || str == null || (typeof str === 'undefined' ? 'undefined' : _typeof(str)) == undefined || str.length == 0 || trim(str).length == 0 || str == ' ') {
    return true;
  } else {
    return false;
  }
};

/*
 * 数组去重
*/
var unique = function unique(arr) {
  var ret = [];
  arr.reduce(function (prev, next) {
    prev[next] = prev[next] + 1 || 1;
    console.log(next);
    if (prev[next] === 1) ret.push(next);
    return prev;
  }, {});
  return ret;
};

/*
 * 判断字符串是否在数组中
 * params: {key:需要判断的字符串，arr：当前指定的数组}
 * result：{
 *     在: 删除
 *     否:添加到数组中}
*/
var in_array = function in_array(key, oldArr) {
  var arr = [].concat(oldArr);
  for (var i = 0; i < oldArr.length; i += 1) {
    if (arr[i] === key) {
      arr.splice(i, 1);
    }
  }
  arr.unshift(key);
  return arr;
};

exports.default = {
  getStrLength: getStrLength,
  getScreenHeight: getScreenHeight,
  transformDistance: transformDistance,
  getDistance: getDistance,
  dataToString: dataToString,
  transformDigital: transformDigital,
  dateToHour: dateToHour,
  dateFormat: dateFormat,
  currencyToString: currencyToString,
  isEmpty: isEmpty,
  unique: unique,
  in_array: in_array,
  transformDate: transformDate
};

/***/ }),

/***/ 22:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var modal = weex.requireModule('modal');
var _network = weex.requireModule('wb-network');
var _router = weex.requireModule('wb-router');
var _location = weex.requireModule('wb-location');
var _modal = weex.requireModule('wb-modal');
var _nativerouter = weex.requireModule('wb-nativerouter');

// const _network = (option, cb) => {
//   setTimeout(() => {
//     cb(option)
//   }, 2000)
// }

// 获取工具栏高度
var toolbar = {
  /**
   * 工具栏高度
   */
  height: function height() {
    var env = weex.config.env;

    var height = _nativerouter.nativeNavigationHeight() / env.deviceWidth * 750;
    return Math.ceil(height);
  }
};

// 加载动画
var loading = {
  /**
   * 打开菊花
   * @param {String} text - 参数
   */
  show: function show(text) {
    _modal.showLoading(text || '加载中...');
  },

  /**
   * 关闭菊花
   */
  hide: function hide() {
    _modal.dismiss();
  }
};

/**
 * 网络请求
 * @param {object} option - 参数
 * @param {string} option.url - 服务器 URL.
 * @param {string} [option.method=get] - 创建请求时使用的方法
 * @param {object} [option.headers={ 'X-Requested-With': 'XMLHttpRequest' }] - 自定义请求头
 * @param {object} [option.params={}] - 请求数据的参数
 * @returns {unknown} - 请求结果,待定
 */
var network = function network(option) {
  return new Promise(function (resolve, reject) {
    var _option = {
      url: null,
      method: 'get',
      // headers: { 'X-Requested-With': 'XMLHttpRequest' },
      params: {}
    };
    var param = Object.assign(_option, option);

    param.method = param.method.toLowerCase();
    console.log('===========================');
    console.log('\u5F00\u59CB\u8BF7\u6C42 url:' + param.url);
    console.log('pafram---:' + JSON.stringify(param));
    _network.request(param, function (result) {
      if (result.status === 401) {
        // 原生处理，跳转到登录
        console.log('登录问题，原生处理');
        console.log(result);
        modal.toast({
          message: result.error,
          duration: 1.5
        });
        return;
      }
      // 原生
      // result.status http请求状态码，成功返回200
      // result.error 错误信息
      // result.data 服务器返回的对象

      // 服务器
      // result.data.code:0 成功
      // result.data.code:10001 权限不足
      // result.data.message 成功 >'ok' 异常 > 异常信息
      // result.data.data 服务器返回数据

      if (result.status === 200) {
        if (result.data.code === 0 || result.data.code === '0') {
          resolve(result.data.data);
          console.log('\u8BF7\u6C42\u6210\u529F url:' + param.url);
          console.log(result);
          console.log('=========================');
        } else {
          loading.hide();
          modal.toast({
            message: result.data.message,
            duration: 1.5
          });
          console.log('数据异常');
          console.error(result);
          console.log('=========================');

          reject(result);
        }
      } else {
        modal.toast({
          message: result.error,
          duration: 1.5
        });

        console.log('请求出错');
        console.error(result);

        reject(result);
      }
    });
  });
};

// 页面路由
var router = {
  /**
   * 打开页面
   * @param {object} option - 参数
   * @param {string} option.url - 下一个weex/web的路径
   * @param {string} [option.name] - 页面名称。内置"weex"、"web"，其他路由需要原生先注册
   * @param {string} [option.type=push] - 下一个weex/web的路径
   * @param {boolean} [option.navBarHidden=false] - 是否隐藏导航栏
   * @param {object} [option.params={}] - // 需要传到下一个页面的数据
   */
  open: function open(option) {
    var _option = {
      name: 'weex',
      url: null,
      type: 'push',
      navBarHidden: false,
      params: {}
    };
    var param = Object.assign(_option, option);
    _router.open(param);
  },

  /**
   * 关闭页面
   * @param {string} [level=1] - 关闭页面的级数
   */
  close: function close() {
    var level = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

    _router.close(level);
  },

  /**
   * 刷新weex页面
   */
  refresh: function refresh() {
    _router.refresh();
  },

  /**
   * 获取页面参数
   */
  getParams: function getParams() {
    return _router.getParams();
  }
};

// 地理定位
var location = new Promise(function (resolve, reject) {
  _location.getLocation(function (result) {
    if (result.status === 0) {
      resolve(result.data);
    } else {
      reject(result);
    }
  });
});

exports.default = {
  network: network,
  router: router,
  location: location,
  loading: loading,
  toolbar: toolbar
};

/***/ }),

/***/ 23:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});


var host = 'api';
// const host = 'http://iquest-test94.aiyuangong.com/api'
/* 接口类别 */
// 任务
var task = host + '/task';

// 好友
var friends = host + '/friends';

// 个人信息
var user = host + '/user';

// 群组
var group = host + '/group';

// 评价
var account = host + '/account';

// 账户
var personal = host + '/personal';

// 搜索
var search = host + '/search';

// 安全验证相关
var auth = host + '/auth';

/* eslint-disable no-new */
exports.default = {
  /**
   * 任务
   */

  // 任务-申请任务
  applyTask: task + '/apply',
  // 任务首页 推荐列表
  taskRecommendList: task + '/special/recommendList',
  // 任务首页 最新列表
  taskNewestList: task + '/special/recommendList',
  // 任务首页 附近列表
  taskNearList: task + '/special/recommendList',
  // 任务首页 信用列表
  taskCreditList: task + '/special/recommendList',
  // 任务-过程-列表
  taskProcessList: task + '/processList',
  // 任务 同意参加任务
  taskApproval: task + '/approval',
  // 任务-详情
  taskDetail: task + '/detail',
  // 任务 完成任务列表
  attendList: task + '/attendList',
  // 任务 发布的任务列表
  publishList: task + '/publishList',
  // 任务 最近完成任务列表
  recentlyCompleteTaskList: host + '/user/recentlyCompleteTaskList',
  // 任务 确认完成任务
  taskComplete: task + '/complete',
  // 任务 打分
  taskEvaluate: task + '/evaluate',
  // 任务 邀请打分
  taskeEaluation: task + '/evaluation',
  // 任务 查看任务-确认完成状态
  taskMember: task + '/status/member',
  // 任务 查看任务-申请状态
  taskeApply: task + '/status/apply',
  // 任务 邀请评价列表
  taskeInviteEvaluateList: task + '/inviteEvaluateList',
  // 任务 最近视屏播放
  taskeVideoGetOne: host + '/video/getOne',
  // 任务-邀请用户参加
  invite: task + '/invite',

  /**
   * 好友
   */

  // 好友—关注或者取消关注
  changeFriends: friends + '/changeFriends',
  // 好友-我关注列表(我关注的)
  followListPage: friends + '/followListPage',
  // 好友—获取粉丝列表(关注我的)
  fansListPage: friends + '/fansListPage',

  /**
   * 个人中心
   */

  // 个人信息
  getOne: user + '/getOne',
  // 编辑个人信息
  updateInfo: user + '/updateInfo',
  // 个人视频列表
  UserVideoPage: host + '/video/UserVideoPage',
  // 用户-身份证验证-检查
  verifyCheck: user + '/verify/check',
  // 用户-身份证验证
  verify: user + '/verify',

  /*
  * 账户
  */
  // 冻结列表
  accountFreezeList: account + '/freezeList',
  // 收支记录列表
  accountDetailList: account + '/detailList',
  // 获取钱包余额
  accountBalance: account + '/balance',
  // 支付订单生成
  createOrder: account + '/order/create',
  // 支付成功更新状态
  orderNotify: account + '/order/notify',

  /*
  * 评价
  */
  personalEvaluateList: personal + '/evaluateList',

  /**
   * 群组
   */
  // 群组-创建群
  createGroup: group + '/createGroup',
  // 群组-获取用户加入的群列表
  GroupListPage: group + '/GroupListPage',
  // 群组-获取组成员信息
  getGroupMember: group + '/getGroupMember',
  // 群组-获取群成员列表（分页）
  GroupMemberListPage: group + '/GroupMemberListPage',
  // 群组-获取某一群组信息
  getGroupOne: group + '/getOne',
  // 群组-修改群组信息
  updateGroup: group + '/updateGroup',
  // 群组-邀请加入群
  inviteJoinGroup: group + '/inviteJoinGroup',
  // 群组-用户主动加入群
  joinGroup: group + '/joinGroup',
  // 群组-解散群
  dismissGroup: group + '/dismissGroup',
  // 群组—获取我创建的群
  getMyGroup: group + '/getMyGroup',

  /**
   * 搜索
   */
  // 搜索热门视频
  searchHotVideo: search + '/getHotVideo',
  // 搜索用户
  searchUser: search + '/searchUser',
  // 搜索视频
  searchVideo: search + '/searchVideo',
  // 搜索任务视频
  searchTask: search + '/searchTask',
  // 搜索任务
  searchTaskInfo: search + '/searchTaskInfo',

  /**
   * 安全验证相关
   */
  userInfo: auth + '/me'

};

/***/ }),

/***/ 621:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(622);


/***/ }),

/***/ 622:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(623);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 623:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(624)
)

/* script */
__vue_exports__ = __webpack_require__(625)

/* template */
var __vue_template__ = __webpack_require__(626)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "F:\\aiyuangong\\iQuest-APP\\src\\user\\editGroupInfo\\App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-50f53986"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 624:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "bwrap-gray": {
    "backgroundColor": "#f7f7f7"
  },
  "container": {
    "width": "750",
    "backgroundColor": "#f7f7f7",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "textarea": {
    "width": "690",
    "height": "200",
    "marginTop": "18",
    "paddingTop": "20",
    "paddingRight": "20",
    "paddingBottom": "20",
    "paddingLeft": "20",
    "fontSize": "34",
    "lineHeight": "48",
    "color": "#3d3d3d",
    "backgroundColor": "#ffffff"
  },
  "count": {
    "textAlign": "right",
    "fontSize": "24",
    "color": "#d3d3d3",
    "marginTop": "16"
  }
}

/***/ }),

/***/ 625:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _utils = __webpack_require__(184);

var _utils2 = _interopRequireDefault(_utils);

var _native = __webpack_require__(22);

var _native2 = _interopRequireDefault(_native);

var _url = __webpack_require__(23);

var _url2 = _interopRequireDefault(_url);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var wbEvent = weex.requireModule('wb-event'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var store = weex.requireModule('wb-store');
var modal = weex.requireModule('modal');
var navigator = weex.requireModule('wb-navigator');

exports.default = {
  name: 'replace-text',
  components: {},
  data: function data() {
    return {
      groupId: '',
      edit: '', // 群公告 || 群名称
      oldVal: '',
      placeholder: '',
      autofocus: true,
      count: 0,
      devHeight: 0,
      totalNum: 120,
      disabled: false,
      value: ''
    };
  },
  created: function created() {
    var me = this;
    this.devHeight = _utils2.default.getScreenHeight();

    var routerParams = _native2.default.router.getParams();

    if (routerParams && routerParams.groupId) {
      this.groupId = routerParams.groupId;
      this.edit = routerParams.edit;
      this.oldVal = routerParams.oldVal;

      var title = '';

      if (this.edit === 'name') {
        // 修改名称
        title = '群名称';
        me.placeholder = '改个炫酷的名字吧...';
      } else if (this.edit === 'notice') {
        title = '群公告';
        me.placeholder = '填写公告内容...';
      }

      navigator.setCenterItem({
        text: title,
        color: '3F3453'
      }, function () {});

      me.setRightItems(1);
    } else {
      modal.toast({ message: '\u83B7\u53D6\u4E0D\u5230\u8DEF\u7531\u53C2\u6570:' + JSON.stringify(routerParams), duration: 10 });
    }
  },

  methods: {
    oninput: function oninput(event) {
      this.count = _utils2.default.getStrLength(event.value);
      this.value = event.value;
    },
    onchange: function onchange(event) {
      this.value = event.value;
    },
    save: function save() {
      var me = this;
      _native2.default.loading.show();
      // 右上角不可点击
      this.setRightItems(0);

      var param = {
        group_id: this.groupId
      };
      if (this.edit === 'notice') {
        // 修改公告
        param.group_notice = this.value;
      } else if (this.edit === 'name') {
        // 修改名称
        param.group_name = this.value;
      }
      var option = {
        url: _url2.default.updateGroup,
        method: 'post',
        params: param
      };
      _native2.default.network(option).then(function () {
        if (me.edit === 'notice') {
          wbEvent.emit({
            name: 'editGroupInfo__GroupNotice',
            params: {
              groupId: me.groupId,
              changedResult: me.value
            }
          });
        }
        if (me.edit === 'name') {
          wbEvent.emit({
            name: 'editGroupInfo__GroupName',
            params: {
              groupId: me.groupId,
              changedResult: me.value
            }
          });
          // 通知原生
          store.storeGroupInfo({
            groupName: me.value,
            groupHead: '',
            groupId: me.groupId
          });
        }
        _native2.default.loading.hide();
        _native2.default.router.close();
      });
    },
    setRightItems: function setRightItems(len) {
      var me = this;
      navigator.setRightItems([{
        text: len > 0 ? '保存' : '保存',
        color: len > 0 ? '0BBE08' : 'BEB8C4'
      }], function () {
        if (!len) return;
        me.save();
      });
    }
  }
};

/***/ }),

/***/ 626:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["container"],
    style: {
      height: _vm.devHeight
    }
  }, [_c('textarea', {
    staticClass: ["textarea"],
    attrs: {
      "value": _vm.oldVal,
      "placeholder": _vm.placeholder,
      "placeholderColor": "#beb8c4",
      "autofocus": _vm.autofocus,
      "maxLength": "totalNum",
      "disabled": _vm.disabled
    },
    on: {
      "input": _vm.oninput,
      "change": _vm.onchange
    }
  }), _c('text', {
    staticClass: ["count"]
  }, [_vm._v(_vm._s(_vm.count) + "/" + _vm._s(_vm.totalNum))])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });