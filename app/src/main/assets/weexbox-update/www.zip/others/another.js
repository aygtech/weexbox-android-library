// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 354);
/******/ })
/************************************************************************/
/******/ ({

/***/ 354:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(355);


/***/ }),

/***/ 355:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(356);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 356:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(357)
)

/* script */
__vue_exports__ = __webpack_require__(358)

/* template */
var __vue_template__ = __webpack_require__(359)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "F:\\aiyuangong\\iQuest-APP\\src\\others\\another\\App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-4b841335"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 357:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "bwrap-gray": {
    "backgroundColor": "#f7f7f7"
  },
  "help": {
    "backgroundColor": "#f7f7f7"
  },
  "content": {
    "paddingTop": "30",
    "paddingRight": "20",
    "paddingBottom": "30",
    "paddingLeft": "30"
  },
  "text": {
    "lineHeight": "52",
    "fontSize": "32",
    "color": "#6a6a6a",
    "marginBottom": "25"
  }
}

/***/ }),

/***/ 358:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var navigator = weex.requireModule('wb-navigator');

exports.default = {
  name: 'welcome',
  data: function data() {
    return {};
  },
  created: function created() {
    navigator.setCenterItem({
      text: '其他问题',
      color: '3f3453'
    }, function () {});
  },

  methods: {}
};

/***/ }),

/***/ 359:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["help"]
  }, [_c('div', {
    staticClass: ["content"]
  }, [_c('text', {
    staticClass: ["text"]
  }, [_vm._v("账号与账号安全\n爱收入账号为用户注册爱收入时所使用的手机号。目前阶段我们暂只提供手机验证码方式登录，我们将尽快完善如密码登录、更换注册手机、第三方授权登录等功能。\n登录时如遇收不到验证码的情况，请在登录界面点“收不到验证码”文字按钮，了解解决办法")]), _c('text', {
    staticClass: ["text"]
  }, [_vm._v("提现渠道\n爱收入目前暂时支持支付宝提现，后续会逐步增加新的提现通道。")]), _c('text', {
    staticClass: ["text"]
  }, [_vm._v("客服工作时间与范围\n原则上，爱收入客服不会对用户之间的争议进行主观评判。我们只针对明显的恶意行为、扰乱社区运营的行为、诈骗行为等存在明显的主观恶意的情况进行判断，目的仅为保障用户使用爱收入产品的正常权益。\n对于用户之间的争议，我们建议双方基于公平、友好、互助的原则，通过协商解决。用户之间若产生严重争议导致诉讼等情况，我们可以向有关部门提供争议用户的账户、互动、任务等信息以协助调查，但不会向个人提供任何涉及产品使用、个人隐私等方面的信息。\n客服的工作时间是上午10时至12时，下午14时至17时，其余时间可以根据需要进行留言。如遇客服繁忙的情况，可先给客服留言，客服将逐一回复和处理。")])])])
}]}
module.exports.render._withStripped = true

/***/ })

/******/ });