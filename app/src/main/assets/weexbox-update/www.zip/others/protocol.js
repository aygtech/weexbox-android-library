// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 378);
/******/ })
/************************************************************************/
/******/ ({

/***/ 378:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(379);


/***/ }),

/***/ 379:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(380);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 380:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(381)
)

/* script */
__vue_exports__ = __webpack_require__(382)

/* template */
var __vue_template__ = __webpack_require__(383)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "F:\\aiyuangong\\iQuest-APP\\src\\others\\protocol\\App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7970ee80"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 381:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "bwrap-gray": {
    "backgroundColor": "#f7f7f7"
  },
  "head": {
    "fontSize": "34",
    "color": "#000000",
    "textAlign": "center"
  },
  "content": {
    "paddingTop": "30",
    "paddingRight": "30",
    "paddingBottom": "30",
    "paddingLeft": "30"
  },
  "text-tt": {
    "marginBottom": "30",
    "lineHeight": "48",
    "fontSize": "30",
    "color": "#6a6a6a"
  }
}

/***/ }),

/***/ 382:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var navigator = weex.requireModule('wb-navigator');

exports.default = {
  name: 'protocol',
  data: function data() {
    return {};
  },
  created: function created() {
    navigator.setCenterItem({
      text: '爱收入用户协议',
      color: '3f3453'
    }, function () {});
  },

  methods: {}
};

/***/ }),

/***/ 383:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', [_c('div', {
    staticClass: ["content"]
  }, [_c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("欢迎使用")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("欢迎您使用“爱收入”软件及相关服务（以下简称“本软件”）。\n为了更好地为您提供服务，请您仔细阅读《爱收入用户协议》（以下简称“本协议”）。如您未满18周岁，请您在法定监护人陪同下仔细阅读并充分理解本协议，并征得法定监护人的同意后使用本软件及相关服务。\n除非您完全接受本协议的全部内容，否则您无权下载、安装、注册、登录、使用本软件，或者通过任何方式使用或获得本软件提供的任何服务。若您使用本软件及相关服务，则视为您已充分理解本协议，并承诺作为本协议的一方当事人接受协议的约束。\n如对本协议内容有任何疑问、意见或建议，您发送邮件至service@ishouru.com与我们联系。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("使用规则")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("用户注册成功后，用户注册时使用的手机号和设置的密码即构成用户所拥有的账号，用户账号和密码由用户负责保管；用户应当对以其用户账号进行的所有活动和事件负法律责任。\n用户须对在爱收入的注册信息的真实性、合法性、有效性承担全部责任，用户不得冒充他人；不得利用他人的名义发布任何信息；不得恶意使用注册账号导致其他用户误认；否则爱收入有权立即停止提供服务，收回其账号并由用户独自承担由此而产生的一切法律责任及经济损失。\n用户直接或通过各类方式间接使用爱收入服务和数据的行为，都将被视作已无条件接受本协议全部内容；若用户对本协议的任何条款存在异议，请停止使用爱收入所提供的全部服务。\n用户明确知晓通过爱收入发表或展示的信息为公开的信息，包括发表的视频、图片、文字内容以及个人资料、互动行为等，其他第三方均可以通过爱收入获取用户发表的信息，用户对任何信息的发表即认可该信息为公开的信息，并单独对此行为承担法律责任；任何用户不愿被其他第三人获知的信息都不应该在爱收入上进行发表。爱收入明示其为保密资料的信息除外，如密码、验证码、身份认证信息等。\n用户承诺不得以任何方式利用爱收入直接或间接从事违反中国法律以及社会公德的行为，爱收入有权对违反上述承诺的内容予以删除。\n用户不得利用爱收入服务制作、上载、复制、发布、传播或者转载如下内容：\n    反对宪法所确定的基本原则的；\n    危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；\n    损害国家荣誉和利益的；\n    煽动民族仇恨、民族歧视，破坏民族团结的；\n    侮辱、滥用英烈形象，否定英烈事迹，美化粉饰侵略战争行为的；\n    破坏国家宗教政策，宣扬邪教和封建迷信的；\n    散布谣言，扰乱社会秩序，破坏社会稳定的；\n    散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；\n    侮辱或者诽谤他人，侵害他人合法权益的；\n    含有法律、行政法规禁止的其他内容的信息。\n爱收入有权对用户使用爱收入的情况进行审查和监督，如用户在使用爱收入时违反任何上述规定，爱收入或其授权的人有权要求用户改正或直接采取一切必要的措施（包括但不限于更改或删除用户张贴的内容、暂停或终止用户使用爱收入的权利）以减轻用户不当行为造成的影响。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("知识产权")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("爱收入是一个信息发布、传播、分享及互动平台，我们尊重和鼓励爱收入用户创作的内容，认识到保护知识产权对爱收入生存与发展的重要性，承诺将保护知识产权作为爱收入运营的基本原则之一。\n用户在爱收入上发表的全部原创内容（包括但不限于视频、评论及其他由用户账号发布的图文信息），著作权均归用户本人所有。用户可授权第三方以任何方式使用，不需要得到爱收入的同意。同时，用户将这些内容授予爱收入免费的、不可撤销的、非独家使用许可，爱收入有权将该内容用于爱收入各种形态的产品和服务上，包括但不限于网站以及发表的应用或其他互联网产品。\n由爱收入发起的，包括但不限于可由多人参与的活动、视频、任务、讨论等，所有参与者均同意，相关知识产权归爱收入所有。\n爱收入提供的网络服务中包含的标识、版面设计、排版方式、文本、图片、图形等均受著作权、商标权及其它法律保护，未经相关权利人（含爱收入及其他原始权利人）同意，上述内容均不得在任何平台被直接或间接发布、使用、出于发布或使用目的的改写或再发行，或被用于其他任何商业目的。\n用户应保证其在爱收入发表的内容拥有著作权或已取得合法授权，并且该内容不会侵犯任何第三方的合法权益。如果第三方提出关于著作权的异议，爱收入有权根据实际情况删除相关的内容，且有权追究用户的法律责任。给爱收入或任何第三方造成损失的，用户应负责全额赔偿。\n如果任何第三方侵犯了爱收入用户相关的权利，用户同意授权爱收入或其指定的代理人代表爱收入自身或用户对该第三方提出警告、投诉、发起行政执法、诉讼、进行上诉，或谈判和解，并且用户同意在爱收入认为必要的情况下参与共同维权。\n爱收入有权但无义务对用户发布的内容进行审核，有权根据相关证据结合《侵权责任法》、《信息网络传播权保护条例》等法律法规对侵权信息进行处理。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("个人隐私")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("爱收入将通过技术手段、强化内部管理等办法充分保护用户的个人隐私信息，除法律或有法律赋予权限的政府部门要求或事先得到用户明确授权等原因外，爱收入不对外公开或向第三方透露用户使用爱收入过程中记录或存储的任何隐私信息。\n在用户使用“爱收入”软件及服务的过程中，我们将根据合法、正当、必要的原则，收集必要的用户信息，包括不限于手机号、第三方授权信息、头像、昵称、地理位置信息、移动设备及其授权信息等，以及姓名、身份证、银行卡、第三方支付授权、面部识别认证信息等涉及赏金领取服务所需的必要信息。这些信息将用于：保障产品的基础正常运行，实现各项功能和服务，优化、改善产品和服务，保障产品、服务以及用户使用安全。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("任务悬赏玩法")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("爱收入的任务悬赏玩法指：爱收入根据严格的流程与规范预先设计的，支持用户设定规则发布悬赏任务，并允许其他用户发现、参与、完成任务要求以及根据规则获取悬赏金的一套系统流程。\n用户需要对其使用爱收入的任务悬赏玩法产生的任何行为、内容和结果负责，包括但不限于如：\n      1、在爱收入平台上发布的视频、音频、图片、文字等信息\n      2、在平台上发生的互动行为\n      3、基于爱收入的任务悬赏玩法，在爱收入平台之外发生的任何行为或内容\n爱收入有权但无义务对用户发布的任务及任务悬赏玩法过程中发生的互动内容、行为进行审核，有权根据《计算机信息网络国际联网安全保护管理办法》等法律法规对违法违规内容及行为进行处理。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("赏金与钱包")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("爱收入的任务悬赏玩法中，支持用户使用现金预先支付赏金，并通过可靠的分发机制在符合产品规则的情况下向参与任务的人发放预设的金额，以使任务流程顺利完成。该流程中，任务参与者接受任务视为双方对任务约定达成一致；确认任务参与者完成任务视为双方已履行约定。用户已知发布任务时预付的费用将在确认参与任务者完成任务时发生支付，不应以任何理由向爱收入申请退款、补偿或赔偿。\n如果用户使用他人代付或以其他违规方式支付造成其他用户或第三方权益受损，不得因此要求爱收入作任何补偿或赔偿，爱收入保留随时冻结其钱包余额、暂停或终止其使用各项服务及禁用其账号的权利。若爱收入有任何理由相信用户账号的使用情况涉及非正常支付、作弊或其他异常状况，爱收入有权拒绝该用户继续使用该账号，并根据实际情况采取必要的如冻结账号、禁用账号等措施。\n用户可通过爱收入的任务悬赏玩法获取赏金，获取的赏金将存入该用户账号下的钱包，并在符合规则的情况下使用系统预设的方案进行提现。钱包的使用须遵守《爱收入钱包使用规范》。用户因违规操作或因个人原因泄露账号信息，导致钱包余额发生损失，爱收入不承担任何责任。根据合理需要，爱收入可配合公安机关，在验证用户本人身份与其账号信息一致的情况下提供交易流水等用于取证的必要信息。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("侵权举报")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("针对用户发布在爱收入平台上的任何内容，若爱收入收到来自第三方的任何形式的合理举报，爱收入有权对该内容进行删除，以终止该内容对第三方的合法权益造成侵害。举报内容包括但不限于涉及个人隐私、造谣与诽谤、商业侵权。\n      涉及个人隐私：发布内容中直接涉及身份信息，如个人姓名、家庭住址、身份证号码、工作单位、私人电话等详细个人隐私；\n      造谣、诽谤：发布内容中指名道姓（包括自然人和企业）的直接谩骂、侮辱、虚构中伤、恶意诽谤等；\n      商业侵权：泄露企业商业机密及其他根据保密协议不能公开讨论的内容。\n      用户在爱收入发表的内容仅表明其个人的立场和观点，并不代表爱收入的立场或观点。如果个人或企业发现爱收入上存在侵犯自身合法权益的内容，可以先尝试与作者取得联系，通过沟通协商解决问题。如您无法联系到作者，或无法通过与作者沟通解决问题，您可通过爱收入客服号向爱收入平台进行投诉。为了保证问题能够及时有效地处理，请务必提交真实有效、完整清晰的材料，否则投诉将无法受理。您需要向爱收入提供的投诉材料包括：\n      权利人对涉嫌侵权内容拥有商标权、著作权和/或其他依法可以行使权利的权属证明，权属证明通常是营业执照或组织机构代码证；\n      举报人的身份证明，身份证明可以是身份证或护照；\n      如果举报人非权利人，请举报人提供代表权利人进行举报的书面授权证明。\n      为确保投诉材料的真实性，在侵权举报中，您还需要签署以下法律声明：\n      我本人为所举报内容的合法权利人；\n      我举报的发布在爱收入社区中的内容侵犯了本人相应的合法权益；\n      如果本侵权举报内容不完全属实，本人将承担由此产生的一切法律责任，并承担和赔偿爱收入因根据投诉人的通知书对相关账号的处理而造成的任何损失，包括但不限于爱收入因向被投诉方赔偿而产生的损失及爱收入名誉、商誉损害等。\n      爱收入将在自收到举报的七个工作日内开始处理并给出回复。处理期间，不提供任何电话、邮件及其他方式的查询服务。\n      出现爱收入已经删除或处理的内容，但是百度、谷歌等搜索引擎依然可以搜索到的现象，是因为百度、谷歌等搜索引擎自带缓存，此类问题爱收入无权也无法处理，因此相关申请不予受理。可以自行联系搜索引擎服务商进行处理。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("免责申明")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("用户在爱收入发表的内容仅表明其个人的立场和观点，并不代表爱收入的立场或观点。作为内容的发表者，需自行对所发表内容负责，因所发表内容引发的一切纠纷，由该内容的发表者承担全部法律及连带责任。爱收入不承担任何法律及连带责任。\n爱收入不保证网络服务一定能满足用户的要求，也不保证网络服务不会中断，对网络服务的及时性、安全性、准确性也都不作保证。\n对于因不可抗力或爱收入不能控制的原因造成的网络服务中断或其它缺陷，爱收入不承担任何责任，但将尽力减少因此而给用户造成的损失和影响。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("协议修改")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("根据互联网的发展和有关法律、法规及规范性文件的变化，或者因业务发展需要，爱收入有权对本协议的条款作出修改或变更，一旦本协议的内容发生变动，爱收入将会直接在爱收入网站上公布修改之后的协议内容，该公布行为视为爱收入已经通知用户修改内容。爱收入也可采用电子邮件或私信的传送方式，提示用户协议条款的修改、服务变更、或其它重要事项。\n如果不同意爱收入对本协议相关条款所做的修改，用户有权并应当停止使用爱收入。如果用户继续使用爱收入，则视为用户接受爱收入对本协议相关条款所做的修改。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("协议生效")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("本协议自用户注册爱收入账号之日起生效。\n为了给用户提供更好的服务，爱收入软件及相关服务将持续进行更新，我们也将适时对本协议进行修订。若修订发生对权利义务方面的修改，爱收入将提示用户查阅最新修订版本，并征求用户的同意。")]), _c('text', {
    staticClass: ["text-tt"]
  }, [_vm._v("爱收入拥有对本协议的最终解释权。")])])])
}]}
module.exports.render._withStripped = true

/***/ })

/******/ });