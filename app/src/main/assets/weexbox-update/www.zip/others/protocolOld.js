// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 384);
/******/ })
/************************************************************************/
/******/ ({

/***/ 22:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var modal = weex.requireModule('modal');
var _network = weex.requireModule('wb-network');
var _router = weex.requireModule('wb-router');
var _location = weex.requireModule('wb-location');
var _modal = weex.requireModule('wb-modal');
var _nativerouter = weex.requireModule('wb-nativerouter');

// const _network = (option, cb) => {
//   setTimeout(() => {
//     cb(option)
//   }, 2000)
// }

// 获取工具栏高度
var toolbar = {
  /**
   * 工具栏高度
   */
  height: function height() {
    var env = weex.config.env;

    var height = _nativerouter.nativeNavigationHeight() / env.deviceWidth * 750;
    return Math.ceil(height);
  }
};

// 加载动画
var loading = {
  /**
   * 打开菊花
   * @param {String} text - 参数
   */
  show: function show(text) {
    _modal.showLoading(text || '加载中...');
  },

  /**
   * 关闭菊花
   */
  hide: function hide() {
    _modal.dismiss();
  }
};

/**
 * 网络请求
 * @param {object} option - 参数
 * @param {string} option.url - 服务器 URL.
 * @param {string} [option.method=get] - 创建请求时使用的方法
 * @param {object} [option.headers={ 'X-Requested-With': 'XMLHttpRequest' }] - 自定义请求头
 * @param {object} [option.params={}] - 请求数据的参数
 * @returns {unknown} - 请求结果,待定
 */
var network = function network(option) {
  return new Promise(function (resolve, reject) {
    var _option = {
      url: null,
      method: 'get',
      // headers: { 'X-Requested-With': 'XMLHttpRequest' },
      params: {}
    };
    var param = Object.assign(_option, option);

    param.method = param.method.toLowerCase();
    console.log('===========================');
    console.log('\u5F00\u59CB\u8BF7\u6C42 url:' + param.url);
    console.log('pafram---:' + JSON.stringify(param));
    _network.request(param, function (result) {
      if (result.status === 401) {
        // 原生处理，跳转到登录
        console.log('登录问题，原生处理');
        console.log(result);
        modal.toast({
          message: result.error,
          duration: 1.5
        });
        return;
      }
      // 原生
      // result.status http请求状态码，成功返回200
      // result.error 错误信息
      // result.data 服务器返回的对象

      // 服务器
      // result.data.code:0 成功
      // result.data.code:10001 权限不足
      // result.data.message 成功 >'ok' 异常 > 异常信息
      // result.data.data 服务器返回数据

      if (result.status === 200) {
        if (result.data.code === 0 || result.data.code === '0') {
          resolve(result.data.data);
          console.log('\u8BF7\u6C42\u6210\u529F url:' + param.url);
          console.log(result);
          console.log('=========================');
        } else {
          loading.hide();
          modal.toast({
            message: result.data.message,
            duration: 1.5
          });
          console.log('数据异常');
          console.error(result);
          console.log('=========================');

          reject(result);
        }
      } else {
        modal.toast({
          message: result.error,
          duration: 1.5
        });

        console.log('请求出错');
        console.error(result);

        reject(result);
      }
    });
  });
};

// 页面路由
var router = {
  /**
   * 打开页面
   * @param {object} option - 参数
   * @param {string} option.url - 下一个weex/web的路径
   * @param {string} [option.name] - 页面名称。内置"weex"、"web"，其他路由需要原生先注册
   * @param {string} [option.type=push] - 下一个weex/web的路径
   * @param {boolean} [option.navBarHidden=false] - 是否隐藏导航栏
   * @param {object} [option.params={}] - // 需要传到下一个页面的数据
   */
  open: function open(option) {
    var _option = {
      name: 'weex',
      url: null,
      type: 'push',
      navBarHidden: false,
      params: {}
    };
    var param = Object.assign(_option, option);
    _router.open(param);
  },

  /**
   * 关闭页面
   * @param {string} [level=1] - 关闭页面的级数
   */
  close: function close() {
    var level = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

    _router.close(level);
  },

  /**
   * 刷新weex页面
   */
  refresh: function refresh() {
    _router.refresh();
  },

  /**
   * 获取页面参数
   */
  getParams: function getParams() {
    return _router.getParams();
  }
};

// 地理定位
var location = new Promise(function (resolve, reject) {
  _location.getLocation(function (result) {
    if (result.status === 0) {
      resolve(result.data);
    } else {
      reject(result);
    }
  });
});

exports.default = {
  network: network,
  router: router,
  location: location,
  loading: loading,
  toolbar: toolbar
};

/***/ }),

/***/ 384:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(385);


/***/ }),

/***/ 385:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _App = __webpack_require__(386);

var _App2 = _interopRequireDefault(_App);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_App2.default.el = '#root';
new Vue(_App2.default);

/***/ }),

/***/ 386:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(387)
)

/* script */
__vue_exports__ = __webpack_require__(388)

/* template */
var __vue_template__ = __webpack_require__(389)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "F:\\aiyuangong\\iQuest-APP\\src\\others\\protocolOld\\App.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-f13b43be"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 387:
/***/ (function(module, exports) {

module.exports = {
  "bwrap": {
    "backgroundColor": "#ffffff"
  },
  "bwrap-sub": {
    "backgroundColor": "#ffffff",
    "paddingLeft": "30",
    "paddingRight": "30"
  },
  "bwrap-gray": {
    "backgroundColor": "#f7f7f7"
  },
  "img-cell": {
    "width": "750"
  }
}

/***/ }),

/***/ 388:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _native = __webpack_require__(22);

var _native2 = _interopRequireDefault(_native);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import url from '../../assets/url'

var navigator = weex.requireModule('wb-navigator'); //
//
//
//
//
//
//
//

exports.default = {
  name: 'protocol',
  data: function data() {
    return {
      lists: []
    };
  },
  created: function created() {
    // 获取协议
    this.setData();

    navigator.setCenterItem({
      text: '爱收入用户协议',
      color: '3f3453'
    }, function () {});
  },

  methods: {
    // 获取协议
    setData: function setData() {
      var _this = this;

      var req = {
        url: 'api/help/getHelp',
        method: 'get',
        params: {
          type: 1 // 1:爱收入用户协议,2:联系客服
        }
      };
      var promise = _native2.default.network(req);
      promise.then(function (res) {
        console.log('resres::: ' + JSON.stringify(res));
        _this.lists = res.image_list;
      }).catch(function () {});
    }
  }
};

/***/ }),

/***/ 389:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["container"]
  }, _vm._l((_vm.lists), function(item, index) {
    return _c('div', {
      key: index,
      staticClass: ["img-cell"]
    }, [_c('image', {
      style: {
        width: item.width,
        height: item.height
      },
      attrs: {
        "src": item.src
      }
    })])
  }))
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });